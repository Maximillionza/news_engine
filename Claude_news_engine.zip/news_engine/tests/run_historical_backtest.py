"""
Historical backtest using 10 real major (red-folder) USD economic events
from 2026, reconstructed from web research since this sandbox can't reach
live news/price APIs directly.

IMPORTANT CAVEAT — read before trusting these numbers:
The pre-event "articles" below are NOT pulled from a live news API with
real publish timestamps. They are paraphrased reconstructions of the real
forecast/expectation framing that was actually being reported ahead of
each release (sourced via web search — Reuters, CNBC, Kitco, TradingKey,
FXStreet, GoldSilver, etc.), assigned approximate pre-event timestamps.
The actual outcome (gold's real move) for every event below is real and
confirmed via multiple independent sources.

This is a legitimate test of the SCORING LOGIC — does it correctly map
"hawkish/beat" language to bearish gold calls and "dovish/miss" language
to bullish calls, and does it handle the mixed-signal cases correctly —
but it is not a test of real-world source timing, coverage volume, or
article-selection accuracy, since that requires the live fetch path
(data_layer/event_context.py + real API keys) run outside this sandbox.
"""
import datetime as dt
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from config.settings import UTC_TZ
from data_layer.calendar_feed import EconomicEvent
from data_layer.news_feed import NewsArticle
from scoring.probability_engine import Direction
from scoring.backtest import run_backtest_case_manual, BacktestReport


def art(title, summary, event_time, hours_before, source_type="rss_reuters_business"):
    return NewsArticle(
        title=title,
        summary=summary,
        source=source_type,
        source_type=source_type,
        published_utc=event_time - dt.timedelta(hours=hours_before),
        url="https://example.com/reconstructed-for-backtest",
    )


report = BacktestReport()

# --- 1. July NFP, released Aug 7, 2026 ---
e1 = EconomicEvent("Non-Farm Payrolls (Jul)", "USD", "High", dt.datetime(2026, 8, 7, 12, 30, tzinfo=UTC_TZ))
a1 = [
    art("July jobs growth expected to stay low", "Labor market continues to cool ahead of Friday's report, weak print may reinforce dovish Fed bets", e1.event_time_utc, 30),
    art("Economists brace for downward revisions", "Goldman Sachs flags recent pattern of July payrolls missing consensus and prior months revised lower", e1.event_time_utc, 20),
    art("Gold cautious near highs ahead of NFP", "Dollar holds overnight rebound on Iran deal doubts, traders await payrolls for fresh direction", e1.event_time_utc, 4),
]
report.add(run_backtest_case_manual(e1, a1, "XAUUSD", Direction.BULLISH, "actual -23K vs +80K expected — dollar 7-week low, gold to 7-week highs"))

# --- 2. June NFP, released Jul 2, 2026 ---
e2 = EconomicEvent("Non-Farm Payrolls (Jun)", "USD", "High", dt.datetime(2026, 7, 2, 12, 30, tzinfo=UTC_TZ))
a2 = [
    art("June payrolls preview: moderate growth expected", "Consensus centers near 100K-115K new jobs, strong print risks hawkish Fed adjustment", e2.event_time_utc, 36),
    art("Rate hike risk if jobs data surprises to upside", "Equity and gold markets react primarily to shifting rate differentials from employment report", e2.event_time_utc, 18),
    art("Dollar firm ahead of jobs report", "Markets positioned for a hawkish outcome after strong recent economic data", e2.event_time_utc, 6),
]
report.add(run_backtest_case_manual(e2, a2, "XAUUSD", Direction.BULLISH, "actual +57K vs ~113K expected — gold jumped above $4,100 on miss"))

# --- 3. May NFP, released Jun 5, 2026 ---
e3 = EconomicEvent("Non-Farm Payrolls (May)", "USD", "High", dt.datetime(2026, 6, 5, 12, 30, tzinfo=UTC_TZ))
a3 = [
    art("Gold at make-or-break level ahead of payrolls", "A big beat would reaffirm 2026 Fed rate hike bets, providing legs to dollar uptrend, dragging gold lower", e3.event_time_utc, 34),
    art("Consensus points to slowing job growth", "Forecast range 85K-96K, stable unemployment expected", e3.event_time_utc, 22),
    art("Markets await confirmation of labor cooling", "A stronger-than-expected report may support higher for longer rates, pressuring gold", e3.event_time_utc, 5),
]
report.add(run_backtest_case_manual(e3, a3, "XAUUSD", Direction.BEARISH, "actual +172K vs 85K expected — gold fell ~2.2%, broke below $4,400"))

# --- 4. June CPI, released Jul 14, 2026 ---
e4 = EconomicEvent("CPI (Jun)", "USD", "High", dt.datetime(2026, 7, 14, 12, 30, tzinfo=UTC_TZ))
a4 = [
    art("Gold recovers ahead of inflation figures", "Markets brace for CPI as decisive short-term catalyst, soft print could compress rate-hike odds", e4.event_time_utc, 30),
    art("Cooling inflation could open path for gold rally", "A softer reading would revive dovish Fed bets and support bullion toward 200-day average", e4.event_time_utc, 14),
    art("Gold fell on Iran strikes ahead of CPI print", "Fear trade dominates near-term positioning into inflation data", e4.event_time_utc, 20),
]
report.add(run_backtest_case_manual(e4, a4, "XAUUSD", Direction.BULLISH, "actual -0.4% MoM vs -0.1% expected — gold jumped $90 (+2.25%) to $4,091"))

# --- 5. May CPI, released Jun 10, 2026 ---
e5 = EconomicEvent("CPI (May)", "USD", "High", dt.datetime(2026, 6, 10, 12, 30, tzinfo=UTC_TZ))
a5 = [
    art("Gold tumbles as hot CPI looms", "Consumer price data expected to exceed 4% for first time in years, reinforcing case for Fed rate hikes", e5.event_time_utc, 26),
    art("Rate-hike bets surge on strong jobs, hot CPI expected next", "CME FedWatch prices 72% probability of December hike, hawkish repricing accelerating", e5.event_time_utc, 15),
    art("Higher-than-expected core CPI could pressure gold", "Rising real yields seen weakening gold's appeal if inflation data surprises to upside", e5.event_time_utc, 40),
]
report.add(run_backtest_case_manual(e5, a5, "XAUUSD", Direction.BEARISH, "actual 4.2% YoY, hottest since 2023 — gold fell sharply, multiple sources report -2.4% to -4.4%"))

# --- 6. FOMC decision, Jun 17, 2026 ---
e6 = EconomicEvent("FOMC Rate Decision", "USD", "High", dt.datetime(2026, 6, 17, 18, 0, tzinfo=UTC_TZ))
a6 = [
    art("Fed expected to hold, dot plot in focus", "97% odds of hold priced in, markets watching new Chair Warsh's first dot plot for hawkish tilt", e6.event_time_utc, 30),
    art("Warsh's first meeting seen as hawkish test case", "New Fed Chair widely regarded as inflation hawk, dot plot could reveal 2026 hike bias", e6.event_time_utc, 40),
    art("Gold at $4,347 while stocks hit highs ahead of Fed", "Futures market pricing near-certain hold, focus shifts to guidance language", e6.event_time_utc, 6),
]
report.add(run_backtest_case_manual(e6, a6, "XAUUSD", Direction.BEARISH, "hold as expected, but ~9 of 18 officials projected a 2026 hike — gold fell 0.94% to $4,290.52"))

# --- 7. FOMC June minutes, released Jul 8, 2026 ---
e7 = EconomicEvent("FOMC Minutes (Jun Meeting)", "USD", "Medium", dt.datetime(2026, 7, 8, 18, 0, tzinfo=UTC_TZ))
a7 = [
    art("Committee split nine-to-nine on 2026 hike", "FOMC minutes expected to reveal hawkish argument for September hike alongside dovish hold case", e7.event_time_utc, 24),
    art("Weak June payrolls complicate hawkish case", "57K print seen as weakest in four months, tempering rate-hike conviction ahead of minutes release", e7.event_time_utc, 30),
    art("Markets brace for hawkish language in Fed minutes", "Split committee raises stakes for guidance on September meeting", e7.event_time_utc, 4),
]
report.add(run_backtest_case_manual(e7, a7, "XAUUSD", Direction.BEARISH, "minutes showed hawkish 9-9 split — gold fell 0.75% to $4,075"))

# --- 8. March CPI, released Apr 10, 2026 ---
e8 = EconomicEvent("CPI (Mar)", "USD", "High", dt.datetime(2026, 4, 10, 12, 30, tzinfo=UTC_TZ))
a8 = [
    art("Inflation expected to spike on energy costs", "Iran war-driven oil surge seen pushing March CPI sharply higher, consensus near 1.0% MoM", e8.event_time_utc, 36),
    art("Markets brace for hot inflation print", "Energy-driven CPI spike seen as transitory but could still pressure gold near-term", e8.event_time_utc, 18),
    art("Fed seen looking through energy-driven inflation noise", "Officials tilted toward eventual rate cut despite near-term price spike, per March meeting signals", e8.event_time_utc, 8),
]
report.add(run_backtest_case_manual(e8, a8, "XAUUSD", Direction.BULLISH, "actual 0.9% MoM vs 1.0% expected, 3.3% YoY vs 3.4% expected — softer than feared, gold jumped $10+"))

# --- 9. April CPI, released ~May 13, 2026 ---
e9 = EconomicEvent("CPI (Apr)", "USD", "High", dt.datetime(2026, 5, 13, 12, 30, tzinfo=UTC_TZ))
a9 = [
    art("Inflation seen re-accelerating on energy costs", "Consensus points to 3.7% YoY, highest since 2023, as Hormuz disruption keeps oil elevated", e9.event_time_utc, 30),
    art("Hawkish new Fed chair adds to rate-hike bets", "Incoming Chair Warsh regarded as inflation hawk, hot CPI could cement 2026 hike case", e9.event_time_utc, 20),
    art("Gold correction continues into CPI print", "Bullion down over 20% from January highs as rate-cut expectations collapse", e9.event_time_utc, 10),
]
report.add(run_backtest_case_manual(e9, a9, "XAUUSD", Direction.BEARISH, "actual 3.8% YoY vs 3.7% expected — hotter than forecast, gold fell despite mixed drivers"))

# --- 10. February PPI, released ~Mar 18, 2026 ---
e10 = EconomicEvent("PPI (Feb)", "USD", "High", dt.datetime(2026, 3, 18, 12, 30, tzinfo=UTC_TZ))
a10 = [
    art("Producer prices expected to hold steady", "Consensus points to modest PPI increase, Fed seen maintaining hold stance regardless", e10.event_time_utc, 28),
    art("Fed holds rates, no cuts in sight", "Policymakers want more confirmation inflation is durably contained before any policy shift", e10.event_time_utc, 16),
    art("Gold steady near highs ahead of producer price data", "Markets positioned for limited reaction barring a significant surprise in either direction", e10.event_time_utc, 6),
]
report.add(run_backtest_case_manual(e10, a10, "XAUUSD", Direction.BEARISH, "actual PPI 3.4% vs ~1.7% expected — more than double forecast, gold fell 3.75% to $4,820"))

report.print_report()
