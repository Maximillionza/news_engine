"""
Central config for the fundamental news engine.
API keys are read from environment variables — never hardcode them here.
"""
import os
from zoneinfo import ZoneInfo

# --- Timezones ---
# Masood is based in South Africa (SAST, UTC+2, no DST)
LOCAL_TZ = ZoneInfo("Africa/Johannesburg")
NY_TZ = ZoneInfo("America/New_York")     # most US macro releases are quoted in this tz
UTC_TZ = ZoneInfo("UTC")

# --- API keys (set these as environment variables before running) ---
ALPHA_VANTAGE_API_KEY = os.environ.get("ALPHA_VANTAGE_API_KEY", "")
APITUBE_API_KEY = os.environ.get("APITUBE_API_KEY", "")

# --- Instruments tracked ---
# Each entry maps an instrument to the USD relationship used for directional logic
# "inverse" = instrument tends to move opposite to USD strength (e.g. gold, EURUSD)
# "direct"  = instrument tends to move with USD strength (e.g. USDJPY, US30 is more nuanced — risk-driven)
INSTRUMENTS = {
    "XAUUSD": {"label": "Gold", "usd_relationship": "inverse"},
    "US30":   {"label": "Dow Jones / US30", "usd_relationship": "risk_sentiment"},
}

# --- Rolling window config ---
PRE_EVENT_WINDOW_HOURS = 48   # start forming probability 2 days before a scheduled event
POST_EVENT_REFRESH_MINUTES = 15  # how often to refresh sentiment after release, to catch indecision

# --- Scoring engine config ---
# Exponential time-decay half-life for article weighting — an article this
# many minutes old carries half the weight of a fresh one. Starting value,
# needs tuning once backtesting shows how fast pre-event sentiment actually
# moves markets vs. how fast it goes stale.
TIME_DECAY_HALF_LIFE_MINUTES = 360  # 6 hours

# Window used to split "recent" vs "older" articles for contradiction
# detection — if sentiment in the last RECENT_WINDOW_HOURS disagrees with
# sentiment from before that, the engine flags indecision/fluctuation.
RECENT_WINDOW_HOURS = 6

# Minimum |instrument_score| for a window's sentiment to count as a real
# directional lean rather than noise, used by the contradiction check.
CONTRADICTION_MIN_MAGNITUDE = 0.15

# --- Source trust weighting (0-1), used in scoring engine later ---
# Placeholder starting weights — to be refined after backtest validation.
#
# IMPORTANT: these weights apply only to PRE-EVENT SCORING sources — i.e.
# sources that publish previews/expectations/positioning before a release.
# Official outcome feeds (Fed, BLS) are never scored for sentiment; they're
# ground truth used only by the backtest module to check what actually
# happened. Don't add them here — see data_layer/rss_sources.py for the
# tier split.
SOURCE_TRUST_WEIGHTS = {
    "forexfactory_calendar": 1.0,   # ground truth for scheduled event timing, not sentiment
    "alpha_vantage_news": 0.7,
    "apitube_news": 0.7,
    "rss_reuters_business": 0.85,   # wire service, fast + historically reliable
    "rss_cnbc_top_news": 0.6,
    "rss_cnbc_economy": 0.65,
    "rss_investing_com_forex": 0.55,  # broader syndication, mixed editorial quality
}

# --- Free-tier API sources worth adding later (not yet implemented) ---
# GDELT      — free, huge global news volume, good for a "how much is this
#               story spreading" signal rather than individual article quality
# Finnhub    — free tier has basic news + sentiment, useful as a secondary
#               cross-check against Alpha Vantage
# Marketaux  — free tier, wide source breadth
# NewsAPI.org — free dev tier is development-only (no production use) and
#               delayed, so it's only useful for testing pipeline logic,
#               not for real backtest timestamp accuracy
