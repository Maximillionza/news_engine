"""
News article fetchers — pluggable by source so new providers can be added
without touching the scoring engine downstream.

Each source implementation returns a list of NewsArticle objects normalized
to the same shape: title, summary, source, published_utc, url, and a raw
sentiment score if the provider gives one natively (else None, and the
scoring engine will compute its own later).
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Optional, Protocol

import requests

from config.settings import (
    ALPHA_VANTAGE_API_KEY,
    APITUBE_API_KEY,
    LOCAL_TZ,
    UTC_TZ,
)


@dataclass
class NewsArticle:
    title: str
    summary: str
    source: str                 # publisher name, e.g. "Reuters"
    source_type: str            # which fetcher produced it, e.g. "alpha_vantage_news"
    published_utc: dt.datetime
    url: str
    native_sentiment: Optional[float] = None   # -1.0 (very bearish) to +1.0 (very bullish), if provider supplies it
    tickers: list[str] = field(default_factory=list)
    raw: dict = field(default_factory=dict, repr=False)

    @property
    def published_local(self) -> dt.datetime:
        return self.published_utc.astimezone(LOCAL_TZ)

    def age_minutes(self, now_utc: Optional[dt.datetime] = None) -> float:
        now_utc = now_utc or dt.datetime.now(UTC_TZ)
        return (now_utc - self.published_utc).total_seconds() / 60.0

    def __repr__(self) -> str:
        return f"<NewsArticle {self.title[:60]!r} src={self.source} age={self.age_minutes():.0f}m>"


class NewsSource(Protocol):
    """Interface every news source fetcher must implement."""
    name: str

    def fetch(self, query: str, since_utc: dt.datetime, limit: int = 50) -> list[NewsArticle]:
        ...


class AlphaVantageNewsSource:
    """
    Alpha Vantage NEWS_SENTIMENT endpoint.
    Docs: https://www.alphavantage.co/documentation/#news-sentiment
    Free tier: 25 requests/day as of last check — verify current limits
    before relying on this for continuous polling.
    """
    name = "alpha_vantage_news"
    BASE_URL = "https://www.alphavantage.co/query"

    def __init__(self, api_key: str = ALPHA_VANTAGE_API_KEY):
        if not api_key:
            raise ValueError("ALPHA_VANTAGE_API_KEY not set")
        self.api_key = api_key

    def fetch(self, query: str, since_utc: dt.datetime, limit: int = 50) -> list[NewsArticle]:
        params = {
            "function": "NEWS_SENTIMENT",
            "topics": query,          # e.g. "economy_macro,finance"
            "time_from": since_utc.strftime("%Y%m%dT%H%M"),
            "limit": min(limit, 200),
            "apikey": self.api_key,
        }
        resp = requests.get(self.BASE_URL, params=params, timeout=15)
        resp.raise_for_status()
        data = resp.json()

        articles = []
        for item in data.get("feed", []):
            try:
                published = dt.datetime.strptime(item["time_published"], "%Y%m%dT%H%M%S").replace(tzinfo=UTC_TZ)
            except (KeyError, ValueError):
                continue

            articles.append(
                NewsArticle(
                    title=item.get("title", ""),
                    summary=item.get("summary", ""),
                    source=item.get("source", "unknown"),
                    source_type=self.name,
                    published_utc=published,
                    url=item.get("url", ""),
                    native_sentiment=item.get("overall_sentiment_score"),
                    tickers=[t.get("ticker") for t in item.get("ticker_sentiment", [])],
                    raw=item,
                )
            )
        return articles


class ApiTubeNewsSource:
    """
    APITube financial news endpoint — good for central bank / macro-event
    specific filtering. Check current API docs for exact param names before
    running, this client targets the general article-search endpoint.
    """
    name = "apitube_news"
    BASE_URL = "https://api.apitube.io/v1/news/everything"

    def __init__(self, api_key: str = APITUBE_API_KEY):
        if not api_key:
            raise ValueError("APITUBE_API_KEY not set")
        self.api_key = api_key

    def fetch(self, query: str, since_utc: dt.datetime, limit: int = 50) -> list[NewsArticle]:
        params = {
            "api_key": self.api_key,
            "q": query,
            "published_at.start": since_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "per_page": min(limit, 100),
            "sort.by": "published_at",
            "sort.order": "desc",
        }
        resp = requests.get(self.BASE_URL, params=params, timeout=15)
        resp.raise_for_status()
        data = resp.json()

        articles = []
        for item in data.get("results", []):
            try:
                published = dt.datetime.fromisoformat(item["published_at"].replace("Z", "+00:00"))
            except (KeyError, ValueError):
                continue

            articles.append(
                NewsArticle(
                    title=item.get("title", ""),
                    summary=item.get("description", ""),
                    source=item.get("source", {}).get("domain", "unknown"),
                    source_type=self.name,
                    published_utc=published,
                    url=item.get("href", ""),
                    native_sentiment=item.get("sentiment", {}).get("overall") if item.get("sentiment") else None,
                    raw=item,
                )
            )
        return articles


def fetch_from_all_sources(
    sources: list[NewsSource],
    query: str,
    since_utc: dt.datetime,
    limit_per_source: int = 50,
) -> list[NewsArticle]:
    """
    Fan out to every configured source and merge results, sorted newest
    first. A failure in one source (bad key, rate limit, etc.) is logged
    and skipped rather than crashing the whole fetch — partial data beats
    no data for this use case.
    """
    all_articles: list[NewsArticle] = []
    for source in sources:
        try:
            all_articles.extend(source.fetch(query, since_utc, limit_per_source))
        except Exception as exc:
            print(f"[news_feed] WARNING: source '{getattr(source, 'name', source)}' failed: {exc}")

    all_articles.sort(key=lambda a: a.published_utc, reverse=True)
    return all_articles


def deduplicate_articles(articles: list[NewsArticle], title_similarity_threshold: float = 0.85) -> list[NewsArticle]:
    """
    Cheap dedup: many stories get syndicated near-verbatim across sources
    around a major release. Exact-title dedup first; near-duplicate title
    matching can be added later (e.g. with rapidfuzz) if this proves too
    permissive during backtesting.
    """
    seen_titles = set()
    deduped = []
    for a in articles:
        key = a.title.strip().lower()
        if key and key not in seen_titles:
            seen_titles.add(key)
            deduped.append(a)
    return deduped
