"""
Forex Factory economic calendar fetcher.

Forex Factory doesn't publish an official developer API. The calendar widget
embedded on partner sites is backed by a public JSON feed hosted by
FairEconomy (the data provider behind FF's widget). This is the same feed
used by countless retail trading tools — no login/auth required, no ToS
violation, it's a public read-only data endpoint.

Feed docs / discovery: https://nfs.faireconomy.media/ff_calendar_thisweek.json
Also available: ff_calendar_lastweek.json, ff_calendar_nextweek.json

NOTE: this sandbox's network egress is locked to a specific domain allowlist
and does not include nfs.faireconomy.media, so this module can't be live
network-tested here. Run it in your own environment (or the eventual MT5/VPS
host) where general internet access is available.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import dataclass, field
from typing import Optional

import requests

from config.settings import LOCAL_TZ, UTC_TZ, PRE_EVENT_WINDOW_HOURS

FF_BASE_URL = "https://nfs.faireconomy.media/ff_calendar_{period}.json"

# Impact levels FF uses in the feed
IMPACT_LEVELS = {"Low", "Medium", "High", "Holiday"}


@dataclass
class EconomicEvent:
    title: str
    country: str          # e.g. "USD"
    impact: str            # Low / Medium / High
    event_time_utc: dt.datetime
    forecast: Optional[str] = None
    previous: Optional[str] = None
    actual: Optional[str] = None
    raw: dict = field(default_factory=dict, repr=False)

    @property
    def event_time_local(self) -> dt.datetime:
        """Event time converted to SAST (Masood's local time)."""
        return self.event_time_utc.astimezone(LOCAL_TZ)

    @property
    def watch_from_local(self) -> dt.datetime:
        """When the pre-event probability window should start, in SAST."""
        return self.event_time_local - dt.timedelta(hours=PRE_EVENT_WINDOW_HOURS)

    def is_high_impact_usd(self) -> bool:
        return self.country == "USD" and self.impact == "High"

    def __repr__(self) -> str:
        return (
            f"<EconomicEvent {self.title!r} [{self.country}/{self.impact}] "
            f"local={self.event_time_local.strftime('%Y-%m-%d %H:%M %Z')}>"
        )


def _parse_event_datetime(raw_date: str) -> dt.datetime:
    """
    FF feed timestamps come as ISO 8601 strings, already UTC-offset aware
    (e.g. '2026-08-07T12:30:00-04:00' during EDT). We normalize to UTC.
    """
    parsed = dt.datetime.fromisoformat(raw_date)
    if parsed.tzinfo is None:
        # Fallback: assume US Eastern if no offset present (shouldn't happen with this feed)
        from config.settings import NY_TZ
        parsed = parsed.replace(tzinfo=NY_TZ)
    return parsed.astimezone(UTC_TZ)


def fetch_calendar(period: str = "thisweek", timeout: int = 15) -> list[EconomicEvent]:
    """
    Fetch the raw FF calendar feed for a given period.
    period: 'lastweek' | 'thisweek' | 'nextweek'
    """
    if period not in {"lastweek", "thisweek", "nextweek"}:
        raise ValueError("period must be one of: lastweek, thisweek, nextweek")

    url = FF_BASE_URL.format(period=period)
    resp = requests.get(url, timeout=timeout, headers={"User-Agent": "news-fundamental-engine/0.1"})
    resp.raise_for_status()
    raw_events = resp.json()

    events: list[EconomicEvent] = []
    for item in raw_events:
        try:
            event_time = _parse_event_datetime(item["date"])
        except (KeyError, ValueError):
            continue  # skip malformed entries rather than crash the whole fetch

        events.append(
            EconomicEvent(
                title=item.get("title", "").strip(),
                country=item.get("country", "").strip(),
                impact=item.get("impact", "").strip(),
                event_time_utc=event_time,
                forecast=item.get("forecast") or None,
                previous=item.get("previous") or None,
                actual=item.get("actual") or None,
                raw=item,
            )
        )
    return events


def filter_relevant_events(
    events: list[EconomicEvent],
    countries: tuple[str, ...] = ("USD",),
    min_impact: str = "High",
) -> list[EconomicEvent]:
    """
    Narrow the full calendar down to the events that actually matter for
    gold / US30 directional analysis — high-impact USD releases by default
    (NFP, CPI, FOMC, PCE, ISM, retail sales, etc.)
    """
    impact_rank = {"Low": 1, "Medium": 2, "High": 3}
    min_rank = impact_rank.get(min_impact, 3)

    return [
        e for e in events
        if e.country in countries and impact_rank.get(e.impact, 0) >= min_rank
    ]


def events_in_pre_window(events: list[EconomicEvent], now_utc: Optional[dt.datetime] = None) -> list[EconomicEvent]:
    """
    Of the given events, return those whose pre-event probability window
    (event_time - PRE_EVENT_WINDOW_HOURS) has already started but the event
    itself hasn't passed yet — i.e. events we should currently be tracking.
    """
    now_utc = now_utc or dt.datetime.now(UTC_TZ)
    active = []
    for e in events:
        window_start = e.event_time_utc - dt.timedelta(hours=PRE_EVENT_WINDOW_HOURS)
        if window_start <= now_utc <= e.event_time_utc:
            active.append(e)
    return active


if __name__ == "__main__":
    # Quick manual smoke test — requires network access to nfs.faireconomy.media
    all_events = fetch_calendar("thisweek")
    high_impact_usd = filter_relevant_events(all_events)
    print(f"Fetched {len(all_events)} total events, {len(high_impact_usd)} high-impact USD events this week.\n")
    for ev in high_impact_usd:
        print(ev)
        print(f"   watch from (SAST): {ev.watch_from_local.strftime('%Y-%m-%d %H:%M %Z')}")
