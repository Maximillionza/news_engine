# ROADMAP.md — TradeWise Delivery Roadmap

**Version:** 0.2  
**Owner:** Masood

---

## Phase 0 — Foundation (Pre-Build) ← YOU ARE HERE

**Goal:** All documents complete. Tech stack validated. Minimum dataset pool curated. Legal process initiated. No production code written yet.

### Milestones

**0.1 — Documentation**
- [x] CLAUDE.md
- [x] PRD.md
- [x] GAME_DESIGN.md
- [x] LEARNING_THEORY.md
- [x] MONETISATION.md
- [x] FEATURE_SPEC.md
- [x] DATA_SCHEMA.md
- [x] ARCHITECTURE.md
- [x] CONTENT_SPEC.md
- [x] REGULATORY_NOTES.md
- [x] ROADMAP.md

**0.2 — Content validation**
- [ ] CONTENT_SPEC.md reviewed by a trader who actively trades all 5 setups
- [ ] Trap setup definitions validated
- [ ] Coaching card template completed for at least 10 decision points
- [ ] Arcade challenge pool: minimum 30 candlestick pattern entries, 20 reversal/pullback entries

**0.3 — Dataset curation (MVP minimum)**
- [ ] Source 180+ days of EURUSD 5-minute OHLCV data (Dukascopy or HistData — free)
- [ ] Tag 20 datasets using decision_points schema in DATA_SCHEMA.md
- [ ] 60+ unique decision points tagged and reviewed by a trader
- [ ] Datasets converted to app-ready JSON format
- [ ] Dataset file sizes checked (target <15MB per dataset)
- [ ] At least 2 pure Stage-1 datasets (no traps)
- [ ] At least 3 trap-heavy sessions (is_trap_session = true)

**0.4 — Tech stack validation**
- [ ] TradingView Lightweight Charts WebView bridge prototype (proof of concept — 2–3 days work)
  - Can it render and play OHLCV data offline on iOS?
  - Can it render and play OHLCV data offline on Android?
  - Is the postMessage latency acceptable?
  - If either fails: evaluate Victory Native XL as fallback
- [ ] Supabase project created (dev environment)
- [ ] Cross-app auth test: one Supabase project, two Expo apps, same Apple ID signs into both
- [ ] Expo project scaffolded, all dependencies installed, dev build running on device
- [ ] RevenueCat: account created, test IAP products configured in App Store Connect sandbox

**0.5 — Legal initiation**
- [ ] South Africa legal opinion: FAIS + gambling risk (initiate before build starts)
- [ ] App Store category and age rating confirmed (target: Education, 17+)
- [ ] Play Store category confirmed

---

## Phase 1 — MVP Build

**Goal:** Shippable app with Career Mode, Arcade Mode, learning module, basic mini-game tabs (UI only, no mechanics), IAP, and subscription.

**Estimated duration:** 12–16 weeks  
**Exit criteria:** Beta test on 50+ users. Day-7 retention ≥ 15%. Crash rate < 1%. Points economy sanity check passed.

### Milestones

**1.1 — Infrastructure**
- [ ] Supabase schema deployed (all tables in DATA_SCHEMA.md)
- [ ] RLS policies applied and tested
- [ ] Edge Functions deployed: resolve_trade, resolve_arcade_answer, initiate_transfer, weekly_growth_bonus, check_milestones, check_leverage_unlock, revenuecat_webhook, refresh_leaderboards
- [ ] Scheduled functions configured (transfer processing, weekly growth bonus, leaderboard refresh)
- [ ] Dataset upload pipeline: JSON → Supabase Storage + local SQLite bundle

**1.2 — Auth + Onboarding**
- [ ] Sign in with Apple
- [ ] Sign in with Google
- [ ] Splash → Welcome → Experience Level → Profile Setup → Disclaimer → Home
- [ ] Learning module gate logic

**1.3 — Learning Module**
- [ ] All 7 sections built (slides + illustrations)
- [ ] Quiz engine (3 questions, 2/3 pass, retry logic)
- [ ] Progress save/resume
- [ ] Badge award on completion
- [ ] Risk management standalone module

**1.4 — Career Mode Core**
- [ ] WebView chart rendering (using validated prototype from Phase 0)
- [ ] Dataset loading from SQLite
- [ ] 5× playback engine
- [ ] Pause at decision point
- [ ] Decision UI: direction + lot size (stages 1–2 simplified, 3–4 full) + SL + TP presets
- [ ] No Trade mechanic
- [ ] Lock In → resume → outcome detection
- [ ] resolve_trade Edge Function integration
- [ ] Post-trade card (all outcome types)
- [ ] Coaching cards (Stage 1 win/loss, all stages for No Trade)
- [ ] Session summary screen

**1.5 — Charting Tools + Timeframe Toggle**
- [ ] Horizontal line tool (all tiers)
- [ ] Trendline tool (Intermediate+ tier)
- [ ] Fibonacci retracement tool (Developing+ tier)
- [ ] Timeframe toggle (1M/5M/15M/1H, tier-gated)
- [ ] Tools visible during pause state only

**1.6 — Practice Capital System**
- [ ] Pip value computation per trade
- [ ] Live risk % display before lock-in (Stage 3–4)
- [ ] Margin call simulation (<$50 warning, <$10 blown state)
- [ ] Capital display on session screen and home

**1.7 — Blow-Up Mechanics**
- [ ] Career Mode Blown screen (Soft Restart)
- [ ] Career Mode Death screen (Full Restart)
- [ ] Transfer prompt on death (mini-game funds → career seed)
- [ ] 48-hour transfer processing
- [ ] Narrative cards (blown, restart, loan repaid)

**1.8 — Leverage Tier System**
- [ ] Tier unlock check after every TradePoints update
- [ ] Tier unlock celebration screen
- [ ] Feature gating per tier (tools, timeframes, lot size input)
- [ ] Tier display on Career Hub and Profile

**1.9 — Practice Capital Milestones**
- [ ] Milestone detection on every capital update
- [ ] Milestone badge awards
- [ ] Narrative cards at each milestone
- [ ] Bonus TradePoints on milestone

**1.10 — Perks System**
- [ ] Perks awarded on trigger conditions
- [ ] Perks lost on Soft Restart (except module-based perks)
- [ ] Perks display on Profile
- [ ] Streak Shield perk mechanic

**1.11 — Side Quests**
- [ ] Quest template system (static config)
- [ ] Quest progress tracking
- [ ] Quest display on Home (up to 3 active, 5 for Pro)
- [ ] Quest completion reward (TradePoints + cosmetic if applicable)
- [ ] Quest refresh on session completion

**1.12 — Arcade Mode**
- [ ] 10-challenge session structure
- [ ] All 7 challenge types implemented
- [ ] Timer (Medium: 30s, Hard: 15s)
- [ ] Speed bonus detection
- [ ] In-session streak tracking
- [ ] Accuracy tracking by challenge type
- [ ] Session summary
- [ ] Arcade leaderboard (weekly, resets Monday)

**1.13 — Game Economy**
- [ ] TradePoints floor (100)
- [ ] Win streak multiplier (Career Mode)
- [ ] Weekly growth bonus computation (scheduled)
- [ ] All badge award logic
- [ ] Badge display (profile badge case, leaderboard)

**1.14 — Mini-Game Tabs (UI Shell Only)**
- [ ] PropWise tab: appears after Elite tier or $100k unlock. Shows unlock congratulations + "Coming Soon" placeholder for full mini-game mechanics.
- [ ] CompWise tab: same pattern at Master tier or $250k.
- [ ] Full mini-game mechanics (property buying, returns): Phase 1b or Phase 2

**1.15 — Leaderboard**
- [ ] Career Mode tab (Practice Capital ranking, global)
- [ ] Arcade tab (weekly TradePoints, global)
- [ ] User's own rank pinned
- [ ] 60-minute refresh

**1.16 — Profile**
- [ ] All stat sections
- [ ] Career Readiness Rating computation + display + disclaimer
- [ ] Badge case (earned + locked)
- [ ] Quest log
- [ ] Transfer history
- [ ] Settings

**1.17 — Monetisation**
- [ ] RevenueCat SDK integration
- [ ] Subscription (Pro) paywall
- [ ] Content pack IAP (Advanced Setup Pack, Arcade Challenge Pack)
- [ ] Feature unlock IAP (Session Review, Detailed Analytics)
- [ ] Cosmetic shop (avatar packs, chart themes)
- [ ] Entitlement gating (Pro features gated by entitlement check)
- [ ] Restore Purchases

**1.18 — Disclaimer Architecture**
- [ ] Onboarding disclaimer (active accept)
- [ ] Career Mode session Practice Capital disclaimer
- [ ] Career Readiness Rating disclaimer
- [ ] All disclaimer copy reviewed against REGULATORY_NOTES.md

**1.19 — Offline Support**
- [ ] SQLite caching for datasets, challenges
- [ ] Session state persistence (resume after crash)
- [ ] Pending sync queue (trade resolutions, points updates)
- [ ] Sync on reconnect

**1.20 — QA + Beta**
- [ ] Internal QA: all flows, edge cases, blow-up states, transfer edge cases
- [ ] TestFlight (iOS): 25 users minimum, 2 weeks
- [ ] Play Store Internal (Android): 25 users minimum
- [ ] Day-7 retention measurement
- [ ] Crash rate < 1%
- [ ] Economy sanity check: no rapid TradePoints accumulation via exploit

---

## Phase 1b — Mini-Game Full Mechanics

**Can run in parallel with Phase 1 QA if resources allow.**

- [ ] PropWise: property marketplace, monthly return cycle, PropFunds tracking
- [ ] CompWise: venture marketplace, monthly revenue cycle, BizFunds tracking
- [ ] Full transfer mechanic: initiate_transfer Edge Function live, 48-hour processing, monthly cap enforcement
- [ ] Mini-game to Career Mode transfer UI
- [ ] Cross-app transfer to PropWise/CompWise apps (transfer progress UI + App Store links)
- [ ] PropWise Starter Pack and CompWise Starter Pack IAP (ecosystem starters)

---

## Phase 2 — Competitions (Post Legal Clearance)

**Prerequisite:** All items in REGULATORY_NOTES.md Section 4 build gate checked.

- [ ] Competition infrastructure: tables, leaderboard, entry tracking
- [ ] Monthly competition (in-app prizes first: cosmetics, TradePoints, Pro credit)
- [ ] Competition badge
- [ ] Cash prize competitions: post all legal opinions received

---

## Phase 3 — Instrument Expansion

- [ ] XAUUSD datasets (20 minimum, all conditions)
- [ ] BTCUSD datasets (20 minimum)
- [ ] Instrument selector on Career Mode and Arcade session start
- [ ] "Random" instrument mode
- [ ] Regional leaderboards (country, continent)

---

## Phase 4 — PropWise and CompWise Dedicated Apps

- [ ] PropWise app: full property mechanics, mortgage system, market cycle simulation
- [ ] CompWise app: full business mechanics, hiring, supply chain, competition
- [ ] Cross-app leaderboard (ecosystem-wide ranking)
- [ ] Shared cosmetics (items earned in one app visible across all three)

---

## Dependency Map

```
Phase 0 (Foundation — no code)
    │
    ▼
Phase 1 (MVP Build + Launch)
    │
    ├──── Phase 1b (Mini-Game Full Mechanics) ← can run parallel with 1.20
    │
    ├──── Phase 2 (Competitions) ← blocked on legal review (can run parallel with 1b)
    │
    └──── Phase 3 (Instrument Expansion) ← after MVP launch data reviewed
              │
              └──── Phase 4 (PropWise + CompWise Apps) ← after Phase 3 stable
```

---

## Backlog (Unscheduled)

- Stocks and Futures datasets
- Dark mode
- Haptic feedback on outcomes
- Push notifications (streak reminders, competition alerts, weekly growth bonus)
- Tablet / iPad optimised layouts
- Referral programme (user invites user — TradePoints reward)
- AI-powered trade feedback ("Your SL placement has been consistently too tight across 50 trades — here's why...")
- Web app (react-native-web)
- TradeWise Pro annual subscription discount
- Social: share badge card to social media (generated image)
- Live delayed data feed (Phase 5 — requires data vendor contract and budget)
