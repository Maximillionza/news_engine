# PRD.md — TradeWise Product Requirements Document

**Version:** 0.1 (Pre-build)  
**Last updated:** 2026-06-26  
**Owner:** Masood  
**Status:** Draft — not yet approved for build

---

## 1. Problem Statement

Retail trading has a structural onboarding failure. New traders are funnelled directly from interest to live accounts with no structured intermediate step. The result is a documented 70–80% loss rate in the first 12 months. Existing solutions — YouTube videos, paid courses, paper trading — share a common flaw: they do not create the specific cognitive habit of pre-hoc conviction (deciding before price moves) under repeated, structured conditions.

TradeWise fills this gap by providing a structured, gamified, chart-replay simulator that trains real decision-making skills — including risk management — in a consequence-free environment.

---

## 2. Target Users

### Primary
| Segment | Description |
|---|---|
| New to Trading | Zero prior trading experience. Drawn by curiosity, social media, or a desire for financial independence. Needs vocabulary, concepts, and confidence before anything else. |
| Learning to Trade | Has consumed content (YouTube, courses) but has not found consistent edge. Knows the terminology, struggles to apply it under pressure. |
| Struggling to Trade | Has live account, losing money. Knows something is wrong but cannot diagnose it. May have undisciplined risk management or no clear confluence criteria. |

### Secondary (not optimised for)
| Segment | Description |
|---|---|
| Professional Trader | May use for entertainment or to test new setups in replay. Not the design target. Do not break the app for primary users to serve this segment. |

---

## 3. User Goals

- Understand what a confluence is and why it matters
- Recognise valid confluences across multiple market conditions
- Make entry decisions (direction, lot size, SL, TP) before price moves — not after
- Understand the mechanical impact of lot size and leverage on equity
- Build a trackable history of decision quality over time
- Develop enough pattern recognition to approach a live account with informed confidence

---

## 4. Business Goals

- MVP: Validate the core replay loop holds engagement past 3 sessions
- MVP: Achieve 15%+ day-7 retention (benchmark for skill-based mobile apps)
- Post-MVP: Convert 20% of active users to ad-free subscription
- Post-MVP: Broker partnership as graduation mechanic (revenue per qualified referral)
- Long-term: Become the default credentialling layer between "interested in trading" and "first live deposit"

---

## 5. MVP Feature Requirements

### 5.1 Onboarding

**FR-001: Experience level selection**
- User selects one of: Beginner / Amateur / Professional
- Selection gates learning module behaviour (see FR-003)
- Selection sets default lot size options and UI complexity level
- Can be updated later in profile settings

**FR-002: Profile creation**
- Username, avatar (preset selection, no uploads in MVP)
- Country selection (for Post-MVP regional leaderboards)
- Acceptance of disclaimer (see FR-015)

**FR-003: Learning module gate**
- Beginner: Learning module is mandatory before accessing trading
- Amateur: Prompted to complete learning module. Can defer but receives periodic reminder. Reminder cadence: once per session until completed or dismissed permanently (after 5 dismissals)
- Professional: Same as Amateur but reminder cadence halved

**FR-004: Learning module completion badge**
- Beginner completion → Bronze Learning Badge
- Amateur completion → Silver Learning Badge
- Professional completion → Gold Learning Badge
- Badge displayed on profile, visible on leaderboard entries

### 5.2 Learning Module

**FR-005: Core curriculum**
The learning module covers, in order:
1. What is a financial market (Forex, Metals, Stocks — conceptual only in MVP)
2. How to read a candlestick chart (timeframes, OHLC)
3. What is market structure (trend, range, key levels)
4. What is a confluence (definition + 5 core setups — see CONTENT_SPEC.md)
5. Risk management fundamentals (lot size, stop loss, pip value, risk per trade %)
6. Margin and leverage (conceptual + worked examples)
7. What is a trading plan (brief — not deep strategy)

**FR-006: Module format**
- Slide-based with illustrations. No video in MVP.
- Each section ends with a 3-question quiz. Must pass (2/3 correct) to advance.
- Failed quiz: user sees explanation and retries. No limit on retries.
- Progress saved. User can resume from last completed section.

**FR-007: Risk management module (standalone, also accessible from trading screen)**
- Dedicated sub-module: lot size calculator walkthrough, risk % concept, SL distance impact on position size
- Must be completable independently of the main learning module
- Accessible from the main menu at any time

### 5.3 Trading (Core Replay Loop)

**FR-008: Instrument and timeframe (MVP)**
- MVP: Forex only. EURUSD only. 5-minute timeframe only.
- Chart data: Pre-loaded historical OHLCV datasets. Minimum 180 days of data.
- Datasets curated to include all market conditions: trending up, trending down, ranging, compression. See CONTENT_SPEC.md.

**FR-009: Pre-hoc decision mechanic (non-negotiable)**

The sequence every session:
1. Chart loads. Plays at 5x speed up to a **decision point** (a candle where a valid confluence setup is present — pre-tagged in the dataset)
2. Chart **pauses automatically** at the decision point
3. User is shown the paused chart. Charting tools available (see FR-011)
4. User may toggle between available timeframes to analyse (see FR-010)
5. User must commit all four inputs before the chart plays:
   - Direction: Buy or Sell
   - Lot size: selected from tier-appropriate options
   - Stop Loss: selected from preset options (MVP) or user-defined (Post-MVP)
   - Take Profit: selected from preset options (MVP) or user-defined (Post-MVP)
6. User taps "Lock In Trade"
7. Chart plays forward at 5x speed
8. Outcome is revealed: TP hit (win), SL hit (loss), or neither within session window (neutral — no points change)
9. Post-trade screen shows: direction correct/incorrect, equity impact of lot size choice, where price actually went vs where user placed SL/TP
10. Points updated. Next trade opportunity loads or session ends.

**FR-010: Timeframe toggling**
- Available during decision point pause only. Not during chart play.
- MVP timeframes available: 1-minute, 5-minute, 15-minute, 1-hour
- Higher timeframes show context. Cannot place trade from higher timeframe view — must return to 5-minute to lock in.

**FR-011: Charting tools (available during pause)**
- Horizontal line (support/resistance marking)
- Trend line
- Fibonacci retracement
- All drawings cleared automatically when chart plays. No persistent drawings between trades in MVP.

**FR-012: Trades per session**
- Each session presents between 3 and 7 trade opportunities (pre-defined in dataset curation)
- Session ends when all opportunities are presented or user exits
- Partial session progress is saved. User can resume within 24 hours.

**FR-013: "No Trade" option**
- At each decision point, user may select "No Trade — No Setup" instead of Buy/Sell
- If the dataset tags the opportunity as a valid setup and user selects No Trade: no points awarded, no points deducted. Coaching message shown.
- If the dataset tags the opportunity as a trap/invalid setup and user correctly selects No Trade: +5 bonus points
- This trains the critical skill of not overtrading. See LEARNING_THEORY.md.

**FR-014: Practice Equity tracker**
- Each user has a Practice Equity starting at $10,000 (simulated, clearly labelled)
- Every trade decision — including lot size — affects Practice Equity in real pip-value terms
- Practice Equity is displayed on the session screen and in the profile
- If Practice Equity falls below $1,000: warning displayed. Below $500: "margin call" simulation shown, session paused, brief education card on margin displayed
- Practice Equity can be reset once per 30 days (logged — history retained for analysis)
- Practice Equity resets do not reset points or badges

### 5.4 Disclaimer Architecture

**FR-015: Disclaimer — not just legal boilerplate**
- Shown on first launch, must be actively accepted (checkbox + button, not auto-accepted)
- Shown again at the moment a user first reaches a streak milestone or badge that implies competence
- Content must include:
  - Simulated performance does not predict live trading performance
  - This app does not provide financial advice
  - Trading real money involves risk of loss
  - The Practice Readiness Score is an internal metric, not a regulated qualification
- Contextual reminder: every time a user views their Practice Readiness Score, a one-line disclaimer is shown beneath it
- See REGULATORY_NOTES.md for jurisdiction-specific requirements

**FR-016: Practice Readiness Score**
- Displayed in profile. Not a pass/fail gate.
- Composite metric across: win rate (last 100 trades), correct No-Trade selections, average risk % per trade, consistency (low variance in lot size choices), total sessions completed
- Score range: 0–100
- Labels: 0–30 "Early Stage", 31–60 "Developing", 61–80 "Progressing", 81–100 "Practice-Ready"
- "Practice-Ready" label includes mandatory tooltip: "This score reflects your simulated performance only."
- Score never tells the user they are ready to trade live. It reflects practice quality.

### 5.5 Points System

**FR-017: Points economy**
- Starting balance: 1,000 TradePoints
- Win (TP hit): +10 base points
- Loss (SL hit): −10 base points
- Neutral (neither hit in session window): 0 points
- Correct No-Trade: +5 points
- Incorrect No-Trade (valid setup, user skipped): 0 points (no penalty — no-trade is always safe)
- Professional tier — TP hit at session-high for the move (within 5% of max): additional +5 points
- Professional tier — SL hit deeper than session-low (preventable loss): additional −5 points

**FR-018: Win streak multiplier**
| Streak | Multiplier | Base Points per Win |
|---|---|---|
| 1–4 wins | 1.0x | 10 |
| 5–9 wins | 1.5x | 15 |
| 10–19 wins | 2.0x | 20 |
| 20–29 wins | 2.5x | 25 |
| 30+ wins | 3.0x | 30 |

Streak is broken by any loss or neutral outcome. Streak counter resets to 0. No additional penalty for streak loss beyond streak reset.

**FR-019: Points floor**
- Points cannot go below 100. Floor prevents demoralising new users into zero.
- Floor reached: coaching notification displayed. Not a game-over state.

### 5.6 Badge System

**FR-020: Learning badges** (see FR-004)

**FR-021: Win streak badges**

| Badge | Requirement | Stars |
|---|---|---|
| Bronze Streak | 5-win streak | ⭐ = 5 wins, ⭐⭐ = 10 wins, ⭐⭐⭐ = 20 wins |
| Silver Streak | 20-win streak | ⭐ = 20 wins, ⭐⭐ = 35 wins, ⭐⭐⭐ = 50 wins |
| Gold Streak | 50-win streak | ⭐ = 50 wins, ⭐⭐ = 75 wins, ⭐⭐⭐ = 100 wins |

Badges are earned permanently. Stars upgrade as higher thresholds are reached. Highest badge displayed on leaderboard. Full badge case visible in profile.

**FR-022: Consistency badge (Post-MVP but design now)**
- Awarded for maintaining risk per trade below 2% across 50 consecutive trades
- Signals disciplined position sizing

### 5.7 Leaderboard

**FR-023: MVP leaderboard**
- Global only in MVP
- Ranked by total TradePoints
- Shows: rank, username, avatar, learning badge, highest streak badge, total points
- Updates every 60 minutes (not real-time in MVP)
- User's own rank always visible (pinned to bottom of list if not in top 50)

### 5.8 Monetisation

**FR-024: Ad-supported base tier**
- Banner ad: displayed below chart on session screen. Never overlapping chart or decision inputs.
- Interstitial ad: displayed between sessions (not mid-session). Frequency: maximum once per 3 sessions.
- No popup ads mid-session. No hourly popup mechanic (removed from original concept — see rationale in REGULATORY_NOTES.md and UX rationale in FEATURE_SPEC.md).

**FR-025: Ad-free subscription**
- Price: to be confirmed (benchmark $4.99–$9.99/month)
- Removes all ads
- No other feature difference in MVP. Subscribers do not get trading advantages.
- Managed via RevenueCat

---

## 6. Post-MVP Feature Requirements (Phased)

### Phase 1 — Instrument Expansion + Regional Leaderboards
- Additional instruments: Crypto (BTCUSD), Spot Metals (XAUUSD), Stocks (single stock TBD)
- User can select preferred instrument category or "Random"
- Regional leaderboards: country, continent, global

### Phase 2 — Competitions + Broker Partnership
- Time-limited competitions (weekly/monthly). Points earned during competition window count separately from main leaderboard.
- Cash prizes: requires full legal review per jurisdiction before build. See REGULATORY_NOTES.md.
- Broker graduation mechanic: user with Practice Readiness Score 81+ and 200+ completed sessions sees broker partner offer screen. Referral revenue model.

### Phase 3 — Strategy Marketplace + Diamond Badge
- Third-party strategy educators can submit courses for review
- Approved courses listed in marketplace with badge reward on completion
- Diamond badge added to Gold Learning Badge on completion of first marketplace course
- Revenue: platform takes % of course sales

### Phase 4 — Live Data + Paper Trading Bridge
- Optional live market data feed (delayed 15 min)
- "Live Replay" mode: practise on today's actual market, not historical data
- Requires data licensing. Not free. Budget required.

---

## 7. Out of Scope (Permanently, Unless Revisited)

- Executing real trades (TradeWise is never a broker or trading platform)
- Managing real money
- Providing personalised financial advice
- Storing payment card details (RevenueCat handles this)

---

## 8. Success Metrics

| Metric | MVP Target | Post-MVP Phase 1 Target |
|---|---|---|
| Day-1 retention | 60% | 65% |
| Day-7 retention | 15% | 22% |
| Day-30 retention | 8% | 12% |
| Sessions per active user per week | 3 | 5 |
| Learning module completion rate (Beginner) | 70% | 75% |
| Subscription conversion | — | 15% of 30-day actives |
| Practice Equity margin call rate | Tracked, no target | Below 30% of users |
