# CLAUDE.md — TradeWise App: Cowork Session Context

## What This File Is
This is the master context document for all Cowork sessions building the TradeWise mobile trading education app. Read this first, every session. Then read the document(s) relevant to your current task. Never assume context from prior sessions — it all lives here and in the linked docs.

---

## Project Identity

**App Name (working title):** TradeWise  
**Tagline (working):** "Learn to trade. For real."  
**Platform:** Mobile-first (iOS + Android). React Native unless a session decision overrides this.  
**Stage:** Pre-build. All documents in this repo are the source of truth. No code exists yet.

---

## The One-Line Product Definition

TradeWise is a chart-replay trading simulator that trains novice and struggling traders to identify, evaluate, and act on trade confluences — including risk management — before they risk real money.

---

## Who This Is For (Non-Negotiable)

The target user is **not** a profitable professional trader. Target users are:
- New to trading (no prior experience)
- Learning to trade (some exposure, no consistent edge)
- Struggling to trade (trading live but losing money)

Professional traders may use the app for entertainment. They are not the design target. Do not optimise features for them.

**Core promise to the user:** After consistent use (target: 500 sessions), the user has practised identifying confluences, sizing positions, and managing risk in a consequence-free environment — and is meaningfully better prepared to trade with real money than before.

---

## What the App Is NOT

- Not a paper trading platform (no live market data in MVP)
- Not a social trading network
- Not a signals service
- Not a broker
- Not a gambling product (see REGULATORY_NOTES.md before building any cash prize feature)

---

## Document Map — Read Before Each Task

| Document | When to Read |
|---|---|
| `CLAUDE.md` (this file) | Every session, first |
| `PRD.md` | Feature decisions, scope questions |
| `ARCHITECTURE.md` | Any infrastructure, stack, or data flow work |
| `LEARNING_THEORY.md` | Any feature touching the trading loop, curriculum, or progression |
| `GAME_MECHANICS.md` | Points, badges, streaks, any economy rule |
| `FEATURE_SPEC.md` | Screen-by-screen build work |
| `DATA_SCHEMA.md` | Database, API, or model work |
| `REGULATORY_NOTES.md` | Competitions, cash prizes, readiness signals, disclaimers |
| `CONTENT_SPEC.md` | Chart replay content, confluence definitions, curriculum arc |
| `ROADMAP.md` | Phasing questions, MVP vs post-MVP scope |

---

## MVP Scope Summary

MVP ships with:
- User onboarding + experience level selection
- Learning module (beginner mandatory, others encouraged)
- Chart replay loop: single instrument (Forex EURUSD), single timeframe (5-minute), pre-hoc decision mechanic
- Buy/Sell + SL/TP commitment before chart plays
- Points system (earn/lose, win streak multiplier)
- Badge system (learning badges + win streak badges)
- Basic leaderboard (global only in MVP)
- Simulated account equity tracker (shows impact of lot size + risk decisions)
- Risk management learning module
- Ad-supported base tier + ad-free subscription
- Disclaimer architecture (UX-level, not just legal footer)

MVP does NOT ship with:
- Multiple instruments (added Post-MVP Phase 1)
- Competitions with cash prizes (Post-MVP Phase 2, pending legal)
- Broker graduation partnership (Post-MVP Phase 2)
- Country/region leaderboards (Post-MVP Phase 1)
- Strategy marketplace / Diamond badge track (Post-MVP Phase 3)

---

## Core Mechanic — The Pre-Hoc Decision Loop

This is the most important design constraint in the entire app. Read it carefully.

**The chart PAUSES at a decision point BEFORE price moves.**

The user must commit to ALL of the following before the chart plays:
1. Direction (Buy or Sell)
2. Lot size (chosen from options appropriate to experience level)
3. Stop Loss level (predetermined options or user-defined, based on experience level)
4. Take Profit level (same)

Only after all four inputs are locked does the chart play. This trains pre-hoc conviction — the real cognitive skill of trading — not post-hoc pattern labelling.

Any feature that lets the user observe price movement before committing breaks this mechanic. Do not build it that way regardless of how much simpler it seems.

---

## Tech Stack (Decisions)

- **Mobile framework:** React Native (Expo managed workflow)
- **Charting library:** Lightweight Charts (TradingView open source) via WebView bridge, or Victory Native — to be confirmed in ARCHITECTURE.md session
- **Backend:** Supabase (auth, database, real-time leaderboard)
- **State management:** Zustand
- **Navigation:** React Navigation v6
- **Chart data:** Pre-loaded OHLCV datasets (CSV → JSON, stored in app bundle for MVP). No live data feed in MVP.
- **Payments/subscriptions:** RevenueCat
- **Ads:** Google AdMob

---

## Naming Conventions

- Feature flags use `MVP_` prefix for MVP features, `POST_MVP_` for deferred
- Database tables use `snake_case`
- React components use `PascalCase`
- All currency references in UI are "TradePoints" (never "coins", "tokens", or "$")
- Simulated account balance labelled "Practice Equity" — never "balance" or "funds"
- Readiness signal labelled "Practice Readiness Score" — never "ready to trade live" as a binary

---

## Key Tensions to Hold

1. **Engagement vs. honesty** — The gamification must not manufacture false confidence. If a user is performing poorly across 100 sessions, the app must surface that, not hide it behind streak-loss protection.
2. **Simplicity vs. completeness** — Novice users need a clean, low-friction experience. But skipping risk management to simplify the loop produces users who blow live accounts. Find the simplest version of full mechanics, not a stripped version.
3. **Speed vs. pedagogy** — Chart replay at 5x speed is entertaining. It may not produce skill transfer. Session architecture must balance engagement (speed) with comprehension (pace). See LEARNING_THEORY.md.

---

## Owner / Contact

Project owner: Masood  
All ambiguity goes back to this document first. If this document doesn't resolve it, flag for Masood before building.
