# REGULATORY_NOTES.md — TradeWise Regulatory and Compliance Notes

**Version:** 0.1  
**Owner:** Masood  
**Status:** Research-level notes. NOT legal advice. A qualified attorney in each target jurisdiction must review before the app launches or before any cash prize feature is built.

---

## Critical Notice

This document identifies regulatory risks. It does not resolve them. Before launching in any jurisdiction, obtain a formal legal opinion. The cost of a legal opinion is trivial compared to the cost of a regulatory enforcement action, app store removal, or class action.

---

## 1. Core Product Classification

TradeWise's MVP is a **simulated trading education application**. It involves:
- No real money
- No real trades
- No broker relationship
- No financial advice
- No live market data

This classification is the shield. Every feature must be evaluated against whether it preserves this classification. Features that blur this line create regulatory exposure.

**Key questions for each feature:**

| Feature | Risk if Misclassified | Mitigation |
|---|---|---|
| Points system | Could be classified as a financial instrument if points have real-world value | Points are explicitly non-redeemable for money or goods in MVP. State this in ToS. |
| Practice Readiness Score | Could be construed as a qualification or endorsement to trade | Disclaimer on every display. Label carefully (see PRD.md FR-016). |
| Cash prize competitions | Likely classified as gambling in multiple jurisdictions | Do not build until jurisdiction-specific legal review is complete. |
| Broker referral (Post-MVP) | May require financial services registration as a lead generator | Legal review required per jurisdiction before building. |

---

## 2. Jurisdiction Risk Map

The app will be distributed globally via App Store and Play Store. The following jurisdictions carry the highest regulatory risk and must be specifically reviewed:

### South Africa (FSCA — Financial Sector Conduct Authority)
- **Relevant legislation:** Financial Advisory and Intermediary Services Act (FAIS), Financial Markets Act
- **Risk area:** If TradeWise is construed as providing financial advice or intermediary services, it requires an FSP licence.
- **Mitigation:** The app explicitly does not recommend specific trades, instruments, or strategies. The disclaimer must state this clearly. The learning module must not be framed as "strategy advice."
- **Cash prizes:** South African gambling is regulated under the National Gambling Act. A cash prize competition may require a lottery or gambling licence depending on structure. This is a high-risk area.
- **Recommendation:** Obtain a FAIS opinion from a South African financial regulatory attorney before launch. Obtain a gambling law opinion before any cash prize feature is built.

### United Kingdom (FCA — Financial Conduct Authority)
- **Relevant legislation:** Financial Services and Markets Act 2000 (FSMA), Gambling Act 2005
- **Risk area:** FCA has issued warnings against unregistered financial promotions. Any content that could be construed as a financial promotion (encouraging people to trade) must either be FCA-authorised or fall within a specific exemption.
- **Mitigation:** The app promotes education, not trading. All marketing materials and in-app copy must be reviewed for financial promotion language.
- **Cash prizes:** UK Gambling Commission licence likely required for cash prize competitions with an element of chance. If outcome is purely skill-based (and provably so), a different classification may apply — but this requires legal opinion.

### European Union (ESMA — European Securities and Markets Authority)
- **Relevant legislation:** MiFID II, national implementation varies
- **Risk area:** ESMA has specifically issued warnings about gamified trading apps and their potential to be classified as investment services.
- **Mitigation:** Simulated-only, no real money, no live prices. Must be clearly communicated in all EU-facing materials.
- **Reference:** ESMA published a statement in 2022 on the risks of gamified trading apps. Legal team must review this document.

### United States (SEC, CFTC, state regulators)
- **Risk area:** High complexity. Forex trading apps (even simulated) may interact with CFTC jurisdiction. Investment adviser registration may be required for apps construed as providing investment advice.
- **Recommendation:** US-specific legal review is essential before launch. Consider a "US launch delayed" approach if legal costs are prohibitive in early stage.

### Australia (ASIC)
- **Risk area:** ASIC regulates financial product advice and has active enforcement. Similar risks to UK/EU.

---

## 3. Disclaimer Requirements

The disclaimer is not a legal afterthought. It is a UX feature and a primary risk mitigation. Based on the risk analysis above:

### Required Disclaimer Elements

**Every disclaimer instance must include:**

1. TradeWise is a simulated trading education app. No real money is deposited, traded, or at risk.
2. Simulated trading results do not reflect or predict real trading performance.
3. Nothing in this app constitutes financial advice, investment advice, or a recommendation to trade.
4. Trading financial instruments with real money involves substantial risk of loss and is not suitable for all investors.
5. The Practice Readiness Score is an internal measure of simulated practice performance. It is not a qualification, certification, regulatory endorsement, or guarantee of success in live trading.

### Disclaimer Placement (UX Requirements)

| Placement | When |
|---|---|
| Onboarding (full disclaimer) | First launch. Active acceptance required (checkbox). |
| Learning module complete screen | After badge award. Brief version. |
| Practice Readiness Score display | Every time. One-line version beneath score. |
| Competition entry (Post-MVP) | Before entering any competition with prizes. Full version. |
| Broker referral screen (Post-MVP) | Before any referral link. Full version plus broker-specific risk warning. |
| App Store listing | In description. "Simulated trading only. No real money." |

### What the Disclaimer Must NOT Do
- Must not bury the disclaimer in a terms-of-service document that users scroll past
- Must not use language that makes the disclaimer sound optional
- Must not be placed only at first launch and never again (contextual repetition is required)

---

## 4. Cash Prize Competitions — Build Gate

**Cash prize competitions (Post-MVP Phase 2) are blocked from build until the following are complete:**

- [ ] Legal opinion obtained for South Africa (primary market)
- [ ] Legal opinion obtained for UK
- [ ] Legal opinion obtained for EU (at least Germany and France as largest markets)
- [ ] Legal opinion obtained for US (or US explicitly excluded from competition feature)
- [ ] Legal opinion obtained for Australia
- [ ] ToS updated with competition-specific terms (entry conditions, prize payment, tax obligations)
- [ ] Prize payment infrastructure reviewed (tax reporting requirements in relevant jurisdictions)
- [ ] Age verification mechanism in place (gambling regulations often require 18+ verification)

**Do not begin technical build of cash prize competitions until all items above are checked.**

A safe alternative for MVP competitions: in-app rewards only (ad-free period, bonus TradePoints, cosmetic badges). These carry negligible regulatory risk.

---

## 5. Age and Vulnerable User Considerations

- Minimum age for account creation: 18 years. Must be stated in onboarding and ToS.
- Age is self-declared in MVP (honour system). If competitions with cash prizes launch, age verification via a third-party service is required.
- The app must not be marketed to minors. App Store/Play Store age ratings must reflect this.
- Problem gambling risk: if cash prizes are introduced, a responsible gambling link (e.g. BeGambleAware in UK, or equivalent per jurisdiction) must be displayed in the competition feature.

---

## 6. App Store Compliance

### Apple App Store
- Category: Education (primary) or Finance (if Apple requires due to trading content)
- Age rating: 17+ (due to simulated gambling/financial content)
- Review risk: Apps that appear to facilitate trading or gambling face additional review scrutiny. The app description must clearly state "simulated only" to reduce rejection risk.

### Google Play Store
- Category: Education
- Apps in the Finance category face enhanced review. Classify as Education unless Play Store requires otherwise.
- Similar "simulated only" language required in listing.

---

## 7. Data Protection

- **POPIA (South Africa):** Personal data of South African users must be processed in compliance with the Protection of Personal Information Act. Privacy policy required. Data processing registration may be required (POPIA Section 55 — Information Officer registration).
- **GDPR (EU):** If EU users are onboarded, GDPR compliance is required. Privacy policy, data processing agreements, right to erasure (account deletion must fully anonymise user data — not just soft delete).
- **User data retention:** Define retention periods. For anonymised analytics: indefinite. For personal data: delete or anonymise within 30 days of account deletion request.
- **Data storage location:** Supabase data region should be set to EU if EU users are served (GDPR data residency preference).

---

## 8. Advertising Compliance

- AdMob integration must comply with GDPR consent requirements (consent management platform required for EU users)
- COPPA (US): if under-18 users could access the app, special ad rules apply. Age gate the app at 18+ to avoid COPPA risk.
- Advertising must not misrepresent the app as a live trading platform in ad creative.
