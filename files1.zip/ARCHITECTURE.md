# ARCHITECTURE.md — TradeWise System Architecture

**Version:** 0.1  
**Owner:** Masood

---

## 1. Architecture Principles

1. **Offline-first for core gameplay.** Chart replay must work without internet. A user mid-session should never be blocked by network failure.
2. **Server-authoritative for economy.** Points, badges, and leaderboard updates are computed and stored server-side. The client never self-awards points.
3. **Pre-loaded data in MVP.** No live market data feed in MVP. OHLCV datasets ship in the app bundle or are downloaded on first install. Eliminates data licensing costs and network dependency for core loop.
4. **Thin client.** Business logic lives in Supabase Edge Functions or PostgreSQL functions, not in the React Native client. This makes future platform expansion (web, desktop) cheaper.
5. **Scale lazily.** MVP is built for thousands of users, not millions. Do not over-engineer for scale that doesn't exist yet. Supabase free/pro tier is sufficient for MVP.

---

## 2. Tech Stack

| Layer | Technology | Rationale |
|---|---|---|
| Mobile framework | React Native (Expo managed workflow) | Cross-platform iOS + Android from single codebase. Expo simplifies build pipeline. |
| Language | TypeScript | Type safety across client and shared types |
| Navigation | React Navigation v6 | Industry standard for RN |
| State management | Zustand | Lightweight, minimal boilerplate. Appropriate for this complexity level. |
| Chart rendering | TradingView Lightweight Charts (via WebView) | Best-in-class candlestick charts. Open source. WebView bridge required in RN. See Chart Rendering section below. |
| Backend / DB | Supabase | Auth, PostgreSQL, real-time, storage, edge functions. Managed. Reduces ops overhead. |
| Payments | RevenueCat | Cross-platform subscription management. Handles App Store + Play Store billing. |
| Ads | Google AdMob | Dominant mobile ad network. AdMob React Native SDK. |
| Analytics | PostHog (self-hosted or cloud) | Product analytics. Session tracking, funnel analysis, retention metrics. |
| Error tracking | Sentry | Crash reporting + performance monitoring |
| CI/CD | Expo EAS Build | Cloud build service for iOS and Android |

---

## 3. System Architecture Diagram

```
┌─────────────────────────────────────────────────────┐
│                  Mobile Client                      │
│              (React Native / Expo)                  │
│                                                     │
│  ┌─────────────┐   ┌──────────────┐   ┌─────────┐  │
│  │ Chart View  │   │  Game Engine │   │  UI     │  │
│  │ (WebView +  │   │  (Zustand)   │   │ Screens │  │
│  │ TW Charts)  │   │              │   │         │  │
│  └──────┬──────┘   └──────┬───────┘   └────┬────┘  │
│         │                 │                │        │
│         └─────────────────┴────────────────┘        │
│                           │                         │
│              ┌────────────┼─────────────┐           │
│              │            │             │           │
│         Local SQLite   Zustand      AsyncStorage    │
│         (session      (runtime      (user prefs,   │
│          cache,       state)         auth token)    │
│          OHLCV data)                               │
└───────────────────────────┬─────────────────────────┘
                            │ HTTPS / Supabase Realtime
                            │
┌───────────────────────────▼─────────────────────────┐
│                    Supabase                          │
│                                                     │
│  ┌──────────┐  ┌───────────┐  ┌──────────────────┐  │
│  │  Auth    │  │ PostgreSQL│  │  Edge Functions  │  │
│  │  (JWT)   │  │  (RLS)    │  │  (trade resolve, │  │
│  └──────────┘  └───────────┘  │   badge award,   │  │
│                               │   score compute) │  │
│  ┌──────────────────────┐     └──────────────────┘  │
│  │  Storage             │                           │
│  │  (dataset bundles,   │     ┌──────────────────┐  │
│  │   avatar assets)     │     │  Scheduled Jobs  │  │
│  └──────────────────────┘     │  (leaderboard    │  │
│                               │   refresh 60min) │  │
│                               └──────────────────┘  │
└─────────────────────────────────────────────────────┘
            │                           │
    ┌───────▼──────┐           ┌────────▼───────┐
    │  RevenueCat  │           │  AdMob         │
    │  (IAP / Sub) │           │  (Banner/Inter)│
    └──────────────┘           └────────────────┘
```

---

## 4. Chart Rendering Architecture

The charting requirement is non-trivial in React Native. TradingView Lightweight Charts is the best available library but runs in a browser context.

**Approach: WebView bridge**

1. A static HTML file (`chart.html`) is bundled with the app. It loads TradingView Lightweight Charts from the bundle (not CDN — offline support).
2. A React Native `WebView` component renders this HTML.
3. Data is passed from RN to WebView via `injectedJavaScript` and `postMessage`.
4. Events (playback position, pause signal) are passed back from WebView to RN via `onMessage`.

**Data flow for a session:**
1. Session starts. RN loads the dataset candles from local SQLite (pre-loaded on install).
2. RN sends candle array to WebView via postMessage: `{ type: 'LOAD_CANDLES', data: [...] }`
3. WebView renders chart. Playback engine in WebView JavaScript scrolls through candles at 5× speed.
4. At `trigger_candle_index`, WebView posts to RN: `{ type: 'PAUSE', candleIndex: N }`
5. RN updates state → bottom panel changes to decision UI.
6. User commits. RN posts to WebView: `{ type: 'RESUME', slLevel: X, tpLevel: Y }`
7. WebView draws SL/TP lines, resumes playback.
8. At `outcome_candle_index`, WebView posts: `{ type: 'OUTCOME', outcomeType: 'win' }`
9. RN triggers outcome state.

**Alternative if WebView bridge proves too complex:** Victory Native XL (pure RN charting). Fallback only — lacks the visual quality of TW Lightweight Charts.

---

## 5. Offline Architecture

**What must work offline:**
- Active session replay (all candle data pre-loaded)
- Learning module (all content bundled)
- Trade decisions and outcome display

**What requires connectivity:**
- Auth (login/register)
- Points and badge sync
- Leaderboard
- Subscription status check

**Implementation:**

Local SQLite database (via `expo-sqlite`) stores:
- All OHLCV dataset candles (downloaded once, on first install or on dataset update)
- Current session state (resume from crash)
- Pending trade outcomes (queue for server sync on reconnect)

On reconnect: pending trade outcomes are sent to Supabase Edge Function for authoritative resolution. Server recalculates points and badges. Client state is updated from server response.

**Conflict resolution:** Server is authoritative. If client and server diverge (e.g. after offline session), server state wins. Client never self-awards points permanently.

---

## 6. Dataset Distribution

MVP datasets ship in two ways:

1. **Bundled in app (first 10 datasets):** Included in the app binary. Available immediately after install. ~5–15MB per dataset depending on candle count.

2. **Downloaded on first launch (remaining datasets):** After auth, remaining datasets download in background. Progress indicator on home screen. App is fully playable with bundled datasets while download completes.

Dataset updates: new datasets added server-side. Client checks for new datasets on each app launch. Downloads in background. No forced app update required to add new chart data.

---

## 7. Security

**Auth:** Supabase Auth with JWT. Tokens stored in AsyncStorage (encrypted via `expo-secure-store` for the refresh token).

**RLS:** All PostgreSQL tables have Row Level Security. Users can only read/write their own data. Leaderboard data exposed via a read-only materialised view.

**Points integrity:** Points are computed server-side in a Supabase Edge Function. The client sends trade decisions (direction, lot size, SL, TP). The server computes outcome against the authoritative `decision_points` table and applies points/equity changes. The client never sends a points delta.

**No client-side cheat vectors:** The `correct_direction` field in `decision_points` is readable by the client (RLS allows it — the session is educational, not competitive in the cheat-prevention sense). If this becomes a concern in competitive Post-MVP phases, `correct_direction` can be moved to a server-only computed field.

---

## 8. Third-Party Service Configuration

### Supabase
- Project: one project per environment (dev, staging, prod)
- RLS enabled on all tables
- Edge Functions: TypeScript, deployed via Supabase CLI
- Realtime: used for live leaderboard updates (Post-MVP). Not used in MVP (60-min refresh is sufficient).

### RevenueCat
- Products configured in App Store Connect and Google Play Console before RevenueCat setup
- Single entitlement: `pro` (ad-free)
- Webhook configured to update `subscriptions` table in Supabase on purchase/cancellation

### AdMob
- Ad units: one banner unit, one interstitial unit
- Test ads enabled in development builds
- AdMob mediation: not in MVP. Add if ad fill rate is low post-launch.
- Banner placement: below chart, above safe area on session screen only
- Interstitial trigger: session complete screen, max once per 3 sessions (tracked in client state)

---

## 9. Build and Release Pipeline

**Development:** Expo Go for rapid iteration on non-native features. Dev build for AdMob and RevenueCat testing (both require native modules).

**Staging:** EAS Build (internal distribution). TestFlight (iOS) + Internal Testing Track (Android).

**Production:** EAS Build → App Store + Play Store submission.

**Environment variables:** Managed via EAS Secrets. Never committed to repo.

| Variable | Used For |
|---|---|
| `SUPABASE_URL` | Supabase project URL |
| `SUPABASE_ANON_KEY` | Supabase public anon key |
| `REVENUECAT_IOS_KEY` | RevenueCat iOS API key |
| `REVENUECAT_ANDROID_KEY` | RevenueCat Android API key |
| `ADMOB_IOS_APP_ID` | AdMob iOS app ID |
| `ADMOB_ANDROID_APP_ID` | AdMob Android app ID |
| `POSTHOG_API_KEY` | Analytics |
| `SENTRY_DSN` | Error tracking |

---

## 10. Post-MVP Architecture Additions

### Phase 1 — Multi-instrument
- Additional OHLCV datasets for BTCUSD, XAUUSD, stocks
- `instrument` field on sessions/datasets already supports this
- No architecture change required. Data addition only.

### Phase 2 — Competitions
- New `competitions` and `competition_entries` tables
- Competition leaderboard computed separately from main leaderboard
- Cash prize payout: third-party payout service (Stripe Connect or similar). Legal review required first.

### Phase 3 — Strategy Marketplace
- New `courses`, `course_purchases` tables
- Content delivery: video hosting required (Cloudflare Stream or Mux)
- Payment: Stripe for one-time course purchases (separate from RevenueCat which handles subscriptions)

### Phase 4 — Live Data
- Data vendor integration (e.g. Polygon.io for delayed data, or broker data feed)
- Real-time WebSocket feed replaces pre-loaded OHLCV for Live Replay mode
- Significant cost and licensing implications. Budget required before planning.
