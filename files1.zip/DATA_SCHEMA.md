# DATA_SCHEMA.md — TradeWise Database Schema

**Version:** 0.1  
**Owner:** Masood  
**Database:** Supabase (PostgreSQL)  
**ORM:** Supabase JS client (no separate ORM in MVP)

---

## Design Principles

- All timestamps stored as UTC. Displayed in user's local timezone.
- Soft delete pattern: records marked `deleted_at` not physically removed (except account deletion, which anonymises not deletes)
- All monetary/equity values stored as integers in pips or cents to avoid float precision errors
- Practice Equity stored in USD cents (10000 USD = 1,000,000 cents)
- Points stored as integers only

---

## Entity Map

```
users
 ├── user_profiles (1:1)
 ├── user_stats (1:1, materialised view updated async)
 ├── sessions (1:many)
 │    └── trades (1:many)
 ├── badges (many:many via user_badges)
 ├── subscriptions (1:1)
 └── equity_resets (1:many)

datasets
 └── dataset_candles (1:many)
      └── decision_points (1:many)
```

---

## Tables

---

### `users`
Managed by Supabase Auth. Extended by `user_profiles`.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| id | uuid | PK, default gen_random_uuid() | Supabase Auth user ID |
| email | text | unique, not null | |
| created_at | timestamptz | default now() | |
| last_sign_in_at | timestamptz | | |

---

### `user_profiles`
All non-auth user data.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| id | uuid | PK, FK → users.id | |
| username | text | unique, not null | 3–20 chars, alphanumeric + underscore |
| avatar_id | smallint | not null, default 1 | 1–12 preset avatars |
| country_code | char(2) | not null | ISO 3166-1 alpha-2 |
| experience_level | text | not null | enum: 'beginner', 'amateur', 'professional' |
| trade_points | integer | not null, default 1000 | Floor enforced at application layer |
| practice_equity_cents | bigint | not null, default 1000000 | $10,000.00 in cents |
| current_win_streak | integer | not null, default 0 | |
| longest_win_streak | integer | not null, default 0 | |
| sessions_completed | integer | not null, default 0 | |
| total_trades | integer | not null, default 0 | |
| total_wins | integer | not null, default 0 | |
| total_losses | integer | not null, default 0 | |
| total_neutral | integer | not null, default 0 | |
| total_correct_no_trades | integer | not null, default 0 | |
| learning_module_completed | boolean | not null, default false | |
| learning_module_completed_at | timestamptz | | |
| learning_badge_tier | text | | null until module complete. enum: 'bronze','silver','gold' |
| onboarding_complete | boolean | not null, default false | |
| disclaimer_accepted_at | timestamptz | | null until accepted |
| practice_readiness_score | smallint | | 0–100. Computed async, stored for display performance |
| readiness_score_updated_at | timestamptz | | |
| subscription_tier | text | not null, default 'free' | enum: 'free', 'pro' |
| stage | smallint | not null, default 1 | 1–4. Computed from sessions_completed. See LEARNING_THEORY.md |
| created_at | timestamptz | default now() | |
| updated_at | timestamptz | default now() | |

**Indexes:** `username` (unique), `trade_points` (for leaderboard queries), `country_code` (for regional leaderboard Post-MVP)

---

### `sessions`
Each chart replay session.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| id | uuid | PK | |
| user_id | uuid | FK → users.id, not null | |
| dataset_id | uuid | FK → datasets.id, not null | |
| status | text | not null, default 'active' | enum: 'active', 'complete', 'abandoned' |
| started_at | timestamptz | not null, default now() | |
| completed_at | timestamptz | | null until complete |
| trades_total | smallint | | set on session create from dataset |
| trades_completed | smallint | not null, default 0 | |
| points_earned_this_session | integer | not null, default 0 | net change (can be negative) |
| equity_change_cents | bigint | not null, default 0 | net Practice Equity change this session (signed) |
| win_count | smallint | not null, default 0 | |
| loss_count | smallint | not null, default 0 | |
| neutral_count | smallint | not null, default 0 | |
| streak_at_start | integer | not null | copied from user_profiles at session start |
| streak_at_end | integer | | copied from user_profiles at session complete |
| is_hard_mode | boolean | not null, default false | Stage 4 streak cooldown sessions |

---

### `trades`
Each individual decision point within a session.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| id | uuid | PK | |
| session_id | uuid | FK → sessions.id, not null | |
| user_id | uuid | FK → users.id, not null | Denormalised for query performance |
| decision_point_id | uuid | FK → decision_points.id, not null | |
| sequence_number | smallint | not null | 1-indexed within session |
| user_direction | text | | enum: 'buy', 'sell', 'no_trade'. null if not yet committed |
| lot_size | numeric(5,2) | | e.g. 0.10 |
| sl_preset | text | | enum: 'tight', 'moderate', 'wide', 'custom'. null if no_trade |
| sl_pips | smallint | | Actual SL distance in pips |
| tp_preset | text | | same enum as sl_preset |
| tp_pips | smallint | | Actual TP distance in pips |
| risk_percent | numeric(5,2) | | % of Practice Equity risked. Computed on commit. |
| outcome | text | | null until resolved. enum: 'win','loss','neutral','correct_no_trade','incorrect_no_trade' |
| points_change | integer | | signed. null until resolved. |
| equity_change_cents | bigint | | signed. null until resolved. |
| correct_direction | text | | enum: 'buy','sell','no_trade'. Set from decision_point data. |
| setup_type | text | | copied from decision_point for post-trade display |
| is_trap_setup | boolean | | true if the decision point is a no-trade trap |
| streak_at_decision | integer | not null | user's streak when they made this decision |
| committed_at | timestamptz | | when user locked in |
| resolved_at | timestamptz | | when outcome determined |

---

### `datasets`
A curated collection of historical OHLCV data used for a session type.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| id | uuid | PK | |
| name | text | not null | e.g. "EURUSD_5M_TRENDING_001" |
| instrument | text | not null | enum: 'EURUSD' (MVP). Expands post-MVP. |
| timeframe | text | not null | enum: '5M' (MVP) |
| market_condition | text | not null | enum: 'trending_up','trending_down','ranging','compression','high_vol' |
| decision_point_count | smallint | not null | number of trades in this dataset |
| stage_min | smallint | not null, default 1 | minimum user stage to receive this dataset |
| stage_max | smallint | not null, default 4 | maximum user stage to receive this dataset |
| is_trap_session | boolean | not null, default false | contains mostly no-trade setups |
| active | boolean | not null, default true | set false to retire a dataset |
| created_at | timestamptz | default now() | |

---

### `dataset_candles`
Raw OHLCV data for a dataset. Pre-loaded.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| id | bigserial | PK | |
| dataset_id | uuid | FK → datasets.id, not null | |
| candle_index | integer | not null | 0-indexed position in sequence |
| open | numeric(10,5) | not null | |
| high | numeric(10,5) | not null | |
| low | numeric(10,5) | not null | |
| close | numeric(10,5) | not null | |
| volume | bigint | | |

**Index:** `(dataset_id, candle_index)` for sequential playback queries.

---

### `decision_points`
Pre-tagged trade opportunities within a dataset.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| id | uuid | PK | |
| dataset_id | uuid | FK → datasets.id, not null | |
| trigger_candle_index | integer | not null | chart pauses here |
| correct_direction | text | not null | enum: 'buy','sell','no_trade' |
| is_trap_setup | boolean | not null, default false | correct answer is no_trade |
| setup_type | text | not null | e.g. 'support_engulfing', 'trend_fib_retracement' |
| setup_components | jsonb | not null | array of component names |
| outcome_candle_index | integer | not null | where outcome resolves |
| sl_tight_pips | smallint | | preset tight SL in pips |
| sl_moderate_pips | smallint | | preset moderate SL |
| sl_wide_pips | smallint | | preset wide SL |
| tp_tight_pips | smallint | | preset tight TP |
| tp_moderate_pips | smallint | | |
| tp_wide_pips | smallint | | |
| max_favourable_pips | smallint | | for Pro bonus TP calculation |
| stage_label | text | | 'foundation','recognition','mastery','independence' |
| coaching_text_win | text | | shown after win in Stage 1 |
| coaching_text_loss | text | | shown after loss in Stage 1 |

---

### `user_badges`
Junction table: which badges each user has earned.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| id | uuid | PK | |
| user_id | uuid | FK → users.id, not null | |
| badge_type | text | not null | enum: 'learning','streak_bronze','streak_silver','streak_gold','consistency' |
| star_level | smallint | not null, default 1 | 1–3 |
| earned_at | timestamptz | not null, default now() | |
| trade_id | uuid | FK → trades.id | the trade that triggered the badge (if applicable) |

**Unique constraint:** `(user_id, badge_type)` — one row per badge type, star_level updated on upgrade.

---

### `equity_resets`
Log of Practice Equity resets.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| id | uuid | PK | |
| user_id | uuid | FK → users.id, not null | |
| reset_at | timestamptz | not null, default now() | |
| equity_before_cents | bigint | not null | |
| reason | text | | optional user-supplied reason |

---

### `subscriptions`
Managed primarily by RevenueCat. Mirrored here for server-side feature gating.

| Column | Type | Constraints | Notes |
|---|---|---|---|
| id | uuid | PK | |
| user_id | uuid | FK → users.id, unique, not null | |
| revenuecat_user_id | text | unique | |
| tier | text | not null, default 'free' | enum: 'free','pro' |
| status | text | | enum: 'active','cancelled','expired','trial' |
| current_period_end | timestamptz | | |
| updated_at | timestamptz | default now() | |

---

## Computed Fields (Application Layer, Not DB Columns)

| Field | Computed From | Where Displayed |
|---|---|---|
| Win rate (all time) | total_wins / total_trades | Profile |
| Win rate (last 100) | Last 100 trades query | Profile, Readiness Score |
| Practice Readiness Score | Multi-factor computation (see below) | Profile |
| Current stage | sessions_completed thresholds | App logic |
| Risk per trade % | lot_size × sl_pips × pip_value / practice_equity | Post-trade card |

### Practice Readiness Score Computation

Score is 0–100. Computed from five factors, each weighted:

| Factor | Weight | Measured As |
|---|---|---|
| Win rate (last 100 trades) | 30% | Percentage of wins/total decisive trades |
| Correct No-Trade rate | 20% | correct_no_trades / total trap setups presented |
| Average risk per trade | 20% | % of sessions where avg risk < 2% (inverse scale) |
| Consistency (lot size variance) | 15% | Low variance = high score |
| Sessions completed | 15% | Scaled: 0 sessions = 0, 500 sessions = 100% of this component |

Recomputed after every session. Stored in `user_profiles.practice_readiness_score` for display performance.

---

## Row Level Security (RLS) Policies

All tables have RLS enabled via Supabase.

| Table | Policy |
|---|---|
| user_profiles | Users can read own row. Cannot read others (except username, avatar, badge data — exposed via leaderboard view). |
| sessions | Users can read/write own rows only. |
| trades | Users can read/write own rows only. |
| user_badges | Users can read own rows. Read-only from client (badges written server-side only). |
| datasets | All authenticated users can read. No user writes. |
| dataset_candles | All authenticated users can read. No user writes. |
| decision_points | All authenticated users can read. No user writes. |
| leaderboard_view | All authenticated users can read (materialised view, anonymised). |

---

## Database Functions / Triggers

| Function | Trigger | Purpose |
|---|---|---|
| `update_user_stats_on_trade_resolve` | After INSERT on trades where outcome IS NOT NULL | Updates user_profiles totals, streak, points, equity |
| `enforce_points_floor` | Before UPDATE on user_profiles.trade_points | Prevents trade_points falling below 100 |
| `compute_readiness_score` | After UPDATE on user_profiles.sessions_completed | Recomputes and stores practice_readiness_score |
| `refresh_leaderboard_view` | Scheduled every 60 minutes | Updates materialised leaderboard view |
| `enforce_equity_reset_cooldown` | Before INSERT on equity_resets | Prevents reset if last reset was < 30 days ago |
