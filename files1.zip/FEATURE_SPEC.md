# FEATURE_SPEC.md — TradeWise Screen-by-Screen Feature Specification

**Version:** 0.1  
**Owner:** Masood  
**Read alongside:** PRD.md, GAME_MECHANICS.md, LEARNING_THEORY.md

---

## Navigation Structure (MVP)

```
App Root
├── Auth Stack
│   ├── Splash Screen
│   ├── Onboarding Flow (first launch only)
│   │   ├── Welcome Screen
│   │   ├── Experience Level Selection
│   │   ├── Profile Setup
│   │   └── Disclaimer Accept
│   ├── Login Screen
│   └── Register Screen
│
└── Main Tab Navigator
    ├── Home (Dashboard)
    ├── Learn
    ├── Trade (Chart Replay)
    ├── Leaderboard
    └── Profile
```

---

## Screen Specifications

---

### SCREEN: Splash Screen
**Route:** `/splash`  
**MVP:** Yes

**Purpose:** Brand impression. Auth state check.

**Behaviour:**
- Display logo + wordmark for 1.5 seconds
- Check auth state in background
- If authenticated + onboarding complete → Home
- If authenticated + onboarding incomplete → resume onboarding at last step
- If not authenticated → Welcome Screen

**Components:** Logo, tagline, loading indicator (subtle)  
**No user input required.**

---

### SCREEN: Welcome Screen
**Route:** `/welcome`  
**MVP:** Yes

**Purpose:** First impression for new users. Set tone.

**Content:**
- Headline: "Learn to trade. For real."
- 3-line value statement (not bullet list — prose)
- CTA: "Get Started" → Experience Level Selection
- Secondary link: "Already have an account? Log in"

**Design note:** Single screen, no carousel. Not the place for feature education. That is the onboarding flow's job.

---

### SCREEN: Experience Level Selection
**Route:** `/onboarding/experience`  
**MVP:** Yes

**Purpose:** Gate learning module behaviour. Set UI complexity defaults.

**Options (tap to select, one at a time):**
- **Beginner** — "I'm new to trading. I want to learn from scratch."
- **Amateur** — "I understand the basics. I want to sharpen my skills."
- **Professional** — "I trade regularly. I'm here to test setups and compete."

**Each option shows:**
- Label
- Description (as above)
- What it unlocks (learning module gate behaviour)

**CTA:** "Continue"

**Behaviour:**
- Selection saved to user profile
- Can be changed later in Settings. Badge does not auto-upgrade on change.
- No "skip" option. Selection is required.

---

### SCREEN: Profile Setup
**Route:** `/onboarding/profile`  
**MVP:** Yes

**Fields:**
- Username (required. 3–20 characters. Alphanumeric + underscore. Unique.)
- Avatar selection (grid of 12 preset avatars. No uploads in MVP.)
- Country (searchable dropdown. Required for Post-MVP regional leaderboards.)

**Validation:**
- Username availability checked on blur (not on submit)
- Username taken: inline error with suggestions ("Try tradewise_masood")

**CTA:** "Create Profile"

---

### SCREEN: Disclaimer Accept
**Route:** `/onboarding/disclaimer`  
**MVP:** Yes

**Purpose:** Legal and ethical requirement. Must be active, not passive.

**Content:**
- Heading: "Before you start — important information"
- Four paragraphs (not bullets):
  1. TradeWise is a simulated trading education app. No real money is involved.
  2. Simulated performance does not predict live trading performance.
  3. TradeWise does not provide financial advice. Nothing in this app constitutes a recommendation to trade.
  4. The Practice Readiness Score is an internal measure of your practice quality. It is not a qualification, certification, or endorsement.

**Required interaction:**
- Checkbox: "I have read and understood the above"
- Checkbox must be manually ticked. Cannot auto-tick.
- CTA "Continue" disabled until checkbox ticked.

**Cannot be skipped.** If user exits app before completing, they return to this screen on next launch.

---

### SCREEN: Home (Dashboard)
**Route:** `/home`  
**MVP:** Yes

**Purpose:** Central hub. Entry point to all features. Quick status summary.

**Sections:**

**1. User snapshot (top)**
- Avatar, username, experience level badge, learning badge
- TradePoints balance (large, prominent)
- Current win streak counter
- Practice Equity balance (smaller, below points)

**2. Quick Start — Resume or New Session**
- If incomplete session exists: "Resume Session" card (instrument, session progress, e.g. "3 of 5 trades complete")
- If no incomplete session: "Start Trading" CTA

**3. Progress tile**
- Practice Readiness Score (0–100 with label)
- Sessions completed count
- Tap → Profile screen

**4. Recent activity (last 3 sessions)**
- Session date, outcome summary (e.g. "4 wins, 1 loss, +35 points"), badge earned if any

**5. Learning module CTA (if not completed)**
- Persistent card if module not complete
- Beginner: "Complete your learning module to unlock trading"
- Amateur/Professional: "Continue your learning module" with dismiss option

**No ads on Home screen.**

---

### SCREEN: Learn Hub
**Route:** `/learn`  
**MVP:** Yes

**Purpose:** Access to learning module and risk management module.

**Sections:**
1. Core Learning Module (progress bar, section list, continue CTA)
2. Risk Management Module (separate entry point, always accessible)
3. Post-MVP placeholder tile: "Strategies 2026 — Coming Soon" (greyed out, not tappable)

**Module section list shows:**
- Section name
- Completion status (tick/lock icon)
- Quiz score if completed

---

### SCREEN: Learning Module — Section View
**Route:** `/learn/module/:sectionId`  
**MVP:** Yes

**Format:**
- Slide-based. Swipe to advance (or tap arrow).
- Each slide: title, illustration/diagram area, explanatory text
- Maximum 8 slides per section
- Progress dots at bottom (not a progress bar — avoid "how much longer" anxiety)

**At end of section:** Quiz prompt. "Ready to test yourself? (3 quick questions)"

**Quiz:**
- 3 multiple-choice questions
- One question at a time, full screen
- Must score 2/3 to advance
- Incorrect: shows explanation, offers retry immediately
- No limit on retries
- On pass: completion animation, advance to next section or module complete screen

---

### SCREEN: Learning Module — Complete
**Route:** `/learn/module/complete`  
**MVP:** Yes

**Content:**
- Badge reveal animation (Bronze/Silver/Gold depending on experience level)
- "You've completed the core learning module."
- Brief summary of what was covered (3 lines)
- CTA: "Start Trading"
- Secondary: "View Badge in Profile"

**Disclaimer shown here as well:**
- Small text below badge: "Completing this module means you've been introduced to these concepts. Skill develops through practice."

---

### SCREEN: Trade — Session Select
**Route:** `/trade`  
**MVP:** Yes

**Purpose:** Entry point to a new trading session.

**MVP content:**
- Instrument: EURUSD (Forex) — only option in MVP. Displayed as selected, not a choice.
- Timeframe: 5-minute — only option in MVP. Displayed as selected.
- Session type: Standard (only option in MVP)
- "Start Session" CTA
- "Resume Session" CTA if one exists

**Post-MVP additions:** Instrument selector, category (random/specific), session difficulty.

---

### SCREEN: Trade — Active Session (Chart Replay)
**Route:** `/trade/session/:sessionId`  
**MVP:** Yes

**This is the most complex screen. Described in full.**

**Layout:**
- Top bar: session progress (e.g. "Trade 2 of 5"), TradePoints balance, current streak, exit button (with confirmation modal)
- Chart area: 70% of screen height. Full width.
- Bottom panel: context-sensitive (changes based on session state)
- Banner ad: below bottom panel, above safe area. Hidden if subscribed.

**States:**

**STATE 1: PLAYING**
- Chart scrolls/plays at 5× speed
- Bottom panel: "Watching... Chart will pause at a setup"
- No user input available except exit
- Timeframe toggle: HIDDEN

**STATE 2: PAUSED — DECISION POINT**
- Chart frozen at decision candle
- Bottom panel transforms to decision UI:
  - Direction toggle: BUY (green) | NO TRADE | SELL (red)
  - If Buy or Sell selected: lot size picker appears below
  - Lot size selected: SL picker appears (preset options: tight/moderate/wide in Stage 1-2, expanded in Stage 3-4)
  - SL selected: TP picker appears
  - All four selected: "Lock In Trade" button activates
- Timeframe toggle: VISIBLE (1m / 5m / 15m / 1H tabs)
- Charting tools panel: VISIBLE (horizontal line, trendline, Fibonacci)
- Tools panel is a slide-up drawer, not always-visible (preserves chart space)
- Timer: optional (to be decided — adds pressure, may be appropriate for Stage 3+)

**STATE 3: LOCKED — PLAYING TO OUTCOME**
- All decision inputs frozen and displayed as summary card (direction, lot, SL, TP)
- Chart resumes playing at 5× speed
- SL and TP levels shown as horizontal lines on chart
- Bottom panel: "Watching outcome..."
- Timeframe toggle: HIDDEN
- Tools: HIDDEN

**STATE 4: OUTCOME**
- Chart pauses at outcome point (TP hit, SL hit, or session window end)
- Overlay appears:
  - Large icon: ✓ (green, TP hit) or ✗ (red, SL hit) or — (neutral)
  - Points change: "+20 pts" or "−10 pts" (with streak multiplier shown if applicable)
  - Practice Equity change: "+$200" or "−$100"
  - Risk taken: "You risked 1.2% of your Practice Equity on this trade"
  - Optimal comparison (Stage 2+): "A 1% risk trade here would have been [X] lots"
- Stage 1: Setup label shown ("This was a [Support + Engulfing] setup")
- Stage 2+: No setup label
- CTA: "Next Trade" or "End Session" if last trade

**STATE 5: SESSION COMPLETE**
- Summary screen:
  - Total TradePoints earned/lost this session
  - Running total updated
  - Win/loss/neutral breakdown
  - Practice Equity change for session
  - Any badges earned this session (with animation)
  - Session review (Stage 4 only): button to review each decision point
- CTA: "Back to Home"
- Ad: interstitial shown here if frequency allows (not more than once per 3 sessions)

---

### SCREEN: Leaderboard
**Route:** `/leaderboard`  
**MVP:** Yes

**MVP: Global tab only.**

**List item per user:**
- Rank number
- Avatar
- Username
- Country flag (small)
- Learning badge
- Highest streak badge (with stars)
- TradePoints total

**User's own entry:** Highlighted, pinned to bottom if not in visible range.

**Refresh:** Pull to refresh. Data updates every 60 minutes from server.

**Post-MVP:** Country and Regional tabs added.

---

### SCREEN: Profile
**Route:** `/profile`  
**MVP:** Yes

**Sections:**

**1. Identity**
- Avatar (tap to change)
- Username (tap to edit)
- Experience level badge
- Country

**2. Practice Stats**
- Sessions completed
- Total trades taken
- Win rate (all time)
- Win rate (last 100 trades)
- Longest win streak (all time)
- Current win streak
- Practice Equity current balance + reset button (once per 30 days)

**3. Practice Readiness Score**
- Large score display (0–100)
- Label (Early Stage / Developing / Progressing / Practice-Ready)
- Breakdown by pillar (radar chart or bar chart)
- Disclaimer one-liner: "This score reflects your simulated practice quality only."

**4. Badge Case**
- All earned badges displayed (full colour)
- Locked badges displayed (greyed silhouette with unlock condition)

**5. Settings**
- Experience level (can change. Warning shown: badge will not auto-upgrade.)
- Notifications (on/off)
- Sound effects (on/off)
- Subscription status (upgrade/manage)
- Account (change password, delete account)

---

### SCREEN: Settings — Subscription
**Route:** `/profile/subscription`  
**MVP:** Yes

**Content:**
- Current plan: Free (with ads) or TradeWise Pro (ad-free)
- Pro plan description: Ad-free experience. Same features. Support the app.
- Price: [To be confirmed]
- CTA: "Upgrade to Pro" (RevenueCat paywall)
- If subscribed: "Manage Subscription" (links to platform subscription management)

---

## UX Rules (Apply Everywhere)

1. **No popup ads mid-session.** Ever. Category is non-negotiable. Ads show between sessions only.
2. **Disclaimer context-sensitivity.** Disclaimer language appears near any metric that could imply live trading readiness.
3. **Chart is never obscured by UI during STATE 1 or STATE 3.** Playing states are observation-only. UI chrome must minimise.
4. **No dark patterns.** No fake countdown timers. No "your streak will be lost if you exit" fear mechanics. Exit is always clean with a simple confirmation.
5. **Accessibility.** Colour is never the only signal. Win = green tick + text. Loss = red X + text. Not colour only.
6. **Offline graceful degradation.** Chart replay sessions use pre-loaded data. Sessions can run fully offline. Leaderboard and points sync on next connection.
