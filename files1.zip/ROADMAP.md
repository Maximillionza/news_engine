# ROADMAP.md — TradeWise Delivery Roadmap

**Version:** 0.1  
**Owner:** Masood  
**Format:** Phase → Milestone → Task. Each phase must be fully shipped before the next begins.

---

## Phase 0 — Foundation (Pre-Build) ← YOU ARE HERE

**Goal:** Everything Cowork needs exists and is validated before code is written.

**Exit criteria:** All documents reviewed, tech stack confirmed, 20 datasets curated and tagged, legal opinion initiated.

### Milestones

**0.1 — Documentation complete**
- [x] CLAUDE.md
- [x] PRD.md
- [x] LEARNING_THEORY.md
- [x] GAME_MECHANICS.md
- [x] FEATURE_SPEC.md
- [x] DATA_SCHEMA.md
- [x] ARCHITECTURE.md
- [x] CONTENT_SPEC.md
- [x] REGULATORY_NOTES.md
- [x] ROADMAP.md

**0.2 — Content validation**
- [ ] CONTENT_SPEC.md reviewed by a trader who actively trades these setups
- [ ] 5 confluence setups confirmed as sound
- [ ] Trap setup definitions validated
- [ ] Coaching card template populated for at least 10 decision points

**0.3 — Dataset curation (MVP minimum)**
- [ ] Source 180 days of EURUSD 5-minute OHLCV data (free sources: Dukascopy, HistData)
- [ ] Tag minimum 20 datasets using `decision_points` schema in DATA_SCHEMA.md
- [ ] At least 60 unique decision points tagged and reviewed
- [ ] Datasets converted to app-ready format (JSON)
- [ ] Dataset files size-checked (target under 15MB per dataset)

**0.4 — Tech stack confirmation**
- [ ] TradingView Lightweight Charts WebView bridge prototype built (2–3 days). Proves the chart rendering approach before full build.
- [ ] Supabase project created (dev environment)
- [ ] Expo project scaffolded with all dependencies installed
- [ ] RevenueCat account created, products configured in App Store Connect + Play Store

**0.5 — Legal**
- [ ] South African legal opinion initiated (FAIS + gambling risk)
- [ ] App Store and Play Store category and age rating confirmed

---

## Phase 1 — MVP Build

**Goal:** A fully functional, shippable app covering all MVP features in PRD.md.

**Estimated duration:** 10–14 weeks (team-dependent)  
**Exit criteria:** Internal QA complete. TestFlight/internal track beta passed. Day-7 retention measured on 50+ beta users.

### Milestones

**1.1 — Infrastructure**
- [ ] Supabase schema deployed (all tables in DATA_SCHEMA.md)
- [ ] RLS policies applied
- [ ] Edge Functions: trade resolve, badge award, readiness score compute
- [ ] Auth flow: register, login, session management
- [ ] Dataset upload pipeline: CSV → JSON → Supabase Storage + local bundle

**1.2 — Onboarding Flow**
- [ ] Splash screen
- [ ] Welcome screen
- [ ] Experience level selection
- [ ] Profile setup (username, avatar, country)
- [ ] Disclaimer accept (active checkbox)
- [ ] Learning module gate logic (mandatory vs. encouraged)

**1.3 — Learning Module**
- [ ] All 7 sections — slides built
- [ ] Quiz engine (3 questions, 2/3 pass threshold, retry)
- [ ] Progress save/resume
- [ ] Badge award on completion
- [ ] Risk management standalone module

**1.4 — Chart Replay Core Loop**
- [ ] WebView chart rendering with TW Lightweight Charts
- [ ] Dataset loading from local SQLite
- [ ] Playback engine at 5× speed
- [ ] Pause at decision_point trigger_candle_index
- [ ] Decision UI: direction + lot size + SL + TP (preset options)
- [ ] "Lock In Trade" → resume playback
- [ ] Outcome detection at outcome_candle_index
- [ ] Points computation (server-side Edge Function)
- [ ] Equity computation (server-side)
- [ ] Post-trade coaching card (Stage 1)
- [ ] Session complete screen

**1.5 — Timeframe Toggle + Charting Tools**
- [ ] Timeframe toggle (1M / 5M / 15M / 1H) during pause state only
- [ ] Horizontal line tool
- [ ] Trendline tool
- [ ] Fibonacci retracement tool
- [ ] Tool state: visible during pause, hidden during play

**1.6 — No Trade Mechanic**
- [ ] No Trade button in decision UI
- [ ] Correct/incorrect No Trade logic
- [ ] Bonus points for correct No Trade
- [ ] Coaching card for No Trade outcomes

**1.7 — Practice Equity System**
- [ ] Equity displayed on session screen and profile
- [ ] Equity impact computation per trade (lot size × SL pips × pip value)
- [ ] Margin call simulation at $500 (< $1,000 warning, < $500 trigger)
- [ ] Equity reset (once per 30 days, logged)

**1.8 — Game Economy**
- [ ] Points floor enforcement (100 pts floor)
- [ ] Win streak counter + multiplier
- [ ] Streak badge award logic
- [ ] Badge display (profile, leaderboard)
- [ ] TradePoints balance display

**1.9 — Leaderboard**
- [ ] Global leaderboard (materialised view, 60-min refresh)
- [ ] User's own rank pinned
- [ ] Leaderboard screen with badge display

**1.10 — Profile**
- [ ] All sections (stats, Practice Readiness Score, badge case)
- [ ] Practice Readiness Score computation
- [ ] Settings (experience level, notifications, sound, subscription)

**1.11 — Monetisation**
- [ ] AdMob banner (session screen only)
- [ ] AdMob interstitial (between sessions, max 1 per 3 sessions)
- [ ] RevenueCat subscription (ad-free Pro tier)
- [ ] Ad suppression for Pro subscribers

**1.12 — Disclaimer Architecture**
- [ ] Onboarding disclaimer (active accept)
- [ ] Contextual disclaimer on readiness score
- [ ] Learning module completion disclaimer
- [ ] All disclaimer copy reviewed against REGULATORY_NOTES.md

**1.13 — Offline Support**
- [ ] SQLite dataset caching
- [ ] Session state persistence (resume after crash/exit)
- [ ] Offline trade queue with sync on reconnect

**1.14 — QA + Beta**
- [ ] Internal QA: all flows, all edge cases
- [ ] TestFlight beta (iOS) — 20 users minimum
- [ ] Play Store internal beta (Android) — 20 users minimum
- [ ] Day-7 retention measurement
- [ ] Crash rate < 1% of sessions
- [ ] Points economy sanity check (no unintended rapid accumulation)

---

## Phase 2 — Post-MVP Phase 1: Instrument Expansion + Polish

**Goal:** Expand the content offering. Improve retention with variety.

**Prerequisite:** MVP day-30 retention data. Do not build Phase 2 until you know what is and isn't working in MVP.

**Estimated duration:** 6–8 weeks

### Milestones

**2.1 — New Instruments**
- [ ] XAUUSD (Gold) datasets: 20 datasets minimum, all conditions
- [ ] BTCUSD (Crypto) datasets: 20 datasets minimum
- [ ] Instrument selection on trade session start
- [ ] "Random" instrument mode

**2.2 — Regional Leaderboards**
- [ ] Country leaderboard
- [ ] Continent/regional leaderboard
- [ ] Leaderboard tab navigation (Global / Country / Region)

**2.3 — Consistency Badge**
- [ ] 2% risk-per-trade tracking across consecutive trades
- [ ] Badge award and display

**2.4 — Session Review (Stage 4)**
- [ ] Post-session review screen: each decision point with user choice vs optimal
- [ ] Available for users in Stage 4 (300+ sessions)

**2.5 — Quality Score on Leaderboard**
- [ ] Secondary metric: win rate × sessions (normalised)
- [ ] Displayed alongside TradePoints on leaderboard

**2.6 — Social Share (Badge Cards)**
- [ ] Shareable badge card image (generated on device)
- [ ] Share sheet integration (native share)

---

## Phase 3 — Post-MVP Phase 2: Competitions + Broker Partnership

**Prerequisite:** All items in REGULATORY_NOTES.md Section 4 build gate must be complete.

**Estimated duration:** 8–12 weeks (legal review timeline is the bottleneck)

### Milestones

**3.1 — Competitions (In-App Prizes First)**
- [ ] Competition infrastructure: tables, leaderboard, entry mechanics
- [ ] Weekly competition (in-app prizes: ad-free period, bonus TradePoints, cosmetic items)
- [ ] Monthly competition
- [ ] Competition badge

**3.2 — Cash Prize Competitions (Post Legal Clearance)**
- [ ] Legal opinions received for all target jurisdictions
- [ ] ToS updated
- [ ] Prize payment infrastructure (Stripe or equivalent)
- [ ] Age verification integration
- [ ] Responsible gambling links (where required)
- [ ] Cash prize competitions launched (jurisdiction-gated)

**3.3 — Broker Partnership**
- [ ] Broker partner integration (referral link + tracking)
- [ ] Graduation screen for users with Practice Readiness Score 81+
- [ ] Referral revenue tracking
- [ ] Disclosure: "TradeWise may earn a referral fee if you open an account with this broker"

---

## Phase 4 — Post-MVP Phase 3: Strategy Marketplace

**Estimated duration:** 10–14 weeks

### Milestones

**4.1 — Marketplace Infrastructure**
- [ ] Course submission and review workflow (admin side)
- [ ] Course listing screen
- [ ] Course purchase flow (Stripe)
- [ ] Course completion tracking + Diamond badge

**4.2 — First-Party Content**
- [ ] "Strategies of 2026" course created (in-house)
- [ ] Diamond badge implementation

**4.3 — Third-Party Educator Onboarding**
- [ ] Educator portal (web, not mobile)
- [ ] Revenue split implementation (platform % + payout to educator)

---

## Phase 5 — Post-MVP Phase 4: Live Data

**Prerequisite:** Data vendor contract. Budget approved. Legal review of live data implications.

**Estimated duration:** 12+ weeks

### Milestones

**5.1 — Data Vendor Integration**
- [ ] Vendor selected and contracted
- [ ] 15-minute delayed feed integrated
- [ ] "Live Replay" mode (today's market, delayed)

**5.2 — Live Chart Rendering**
- [ ] WebSocket feed to chart WebView
- [ ] Real-time candlestick rendering
- [ ] Decision point tagging for live sessions (server-side, auto-generated or manual curation)

---

## Backlog (No Phase Assigned Yet)

- Stocks: individual stock datasets (requires clearing on copyright of price data)
- Futures: separate mechanics required (contract expiry, rollover simulation)
- Dark mode
- Haptic feedback on outcomes
- Push notifications (win streak reminders, competition alerts)
- Android tablet + iPad optimised layouts
- Web app (react-native-web)
- Referral programme (user invites user)
- AI-powered trade feedback (Post-MVP: "Your SL placement in the last 20 trades has been consistently too tight — here's why...")

---

## Dependency Map

```
Phase 0 (Docs + Data + Stack Proof)
    │
    ▼
Phase 1 (MVP Build + Launch)
    │
    ├──► Phase 2 (Instrument Expansion) — can start after MVP launch data
    │
    └──► Phase 3 (Competitions) — blocked on legal review
              │
              └──► Phase 4 (Marketplace) — independent of Phase 3
                        │
                        └──► Phase 5 (Live Data) — independent of Phases 3 + 4
```
