# GAME_MECHANICS.md — TradeWise Game Economy

**Version:** 0.1  
**Owner:** Masood  
**Read alongside:** PRD.md (FR-017 to FR-022), LEARNING_THEORY.md

---

## Design Principle

The game economy must reward skill and consistency, not time-in-app. A user who plays 2 hours a day should not automatically outrank a user who plays 20 minutes a day with better decisions. Every mechanic below is evaluated against this principle. If a proposed change rewards volume over quality, it is rejected.

---

## 1. TradePoints Economy

### 1.1 Starting Balance
Every new user begins with **1,000 TradePoints**.

Rationale: Enough to feel meaningful, enough headroom to absorb early losses without hitting the floor immediately.

### 1.2 Point Events

| Event | Points Change | Condition |
|---|---|---|
| Win (TP hit) | +10 base | Modified by streak multiplier |
| Loss (SL hit) | −10 base | No streak multiplier on losses |
| Neutral (neither hit in window) | 0 | No change |
| Correct No-Trade (trap setup, user skips) | +5 | Flat, no multiplier |
| Incorrect No-Trade (valid setup, user skips) | 0 | No penalty. Learning moment only. |
| Pro — TP hit at session-high (within 5% of max move) | +5 bonus | Added to win points. Requires Professional user tier. |
| Pro — SL hit deeper than needed (avoidable loss) | −5 bonus | Added to loss deduction. Requires Professional user tier. |

### 1.3 Win Streak Multiplier

Streak is defined as consecutive wins across sessions (not within a single session). A neutral outcome does NOT break the streak. A loss breaks it.

| Consecutive Wins | Multiplier | Effective Points per Win |
|---|---|---|
| 1–4 | 1.0× | 10 |
| 5–9 | 1.5× | 15 |
| 10–19 | 2.0× | 20 |
| 20–29 | 2.5× | 25 |
| 30+ | 3.0× | 30 |

Points are rounded to nearest whole number. No fractional TradePoints displayed.

### 1.4 Points Floor

**Floor: 100 TradePoints.** Points cannot fall below this value.

When floor is reached:
- Notification: "Your TradePoints are low. Every session is a chance to rebuild. Keep practising."
- No game-over state. Session continues normally.
- Floor is not announced until first time it is hit. Not displayed as a warning before the fact.

Rationale: Eliminating the floor entirely creates a demoralising death spiral for new users. The floor preserves engagement without removing consequence.

### 1.5 Points and Leaderboard Integrity

The leaderboard ranks by total TradePoints. To prevent pure volume gaming:
- In Post-MVP Phase 1, a secondary "Quality Score" column is added (win rate × sessions). This does not replace points ranking but gives context.
- In Post-MVP Phase 2 (competitions), competition ranking uses a composite metric, not raw points. See ROADMAP.md.

---

## 2. Badge System

Badges are permanent once earned. They cannot be lost. Stars can only increase, never decrease.

### 2.1 Learning Badges

Awarded on completion of the learning module. One badge per user. Tier is set by experience level at time of completion.

| Badge | Tier | Requirement |
|---|---|---|
| Bronze Learning Badge | Beginner | Complete learning module as Beginner |
| Silver Learning Badge | Amateur | Complete learning module as Amateur |
| Gold Learning Badge | Professional | Complete learning module as Professional |
| Diamond Enhancement | All tiers | Complete a Post-MVP marketplace strategy course. Adds diamond accent to existing badge. |

If a user changes their experience level after completing the module, the badge does NOT upgrade automatically. To earn a higher badge, user must retake the module at the new level (all quiz questions refreshed).

### 2.2 Win Streak Badges

Streak badges reflect the highest consecutive win streak the user has achieved at any point. Stars within each badge represent milestones.

**Bronze Streak Badge**
| Star | Requirement |
|---|---|
| ⭐ | First 5-win streak |
| ⭐⭐ | First 10-win streak |
| ⭐⭐⭐ | First 20-win streak |

**Silver Streak Badge** (unlocked when user first achieves 20-win streak)
| Star | Requirement |
|---|---|
| ⭐ | First 20-win streak (concurrent with Bronze ⭐⭐⭐ unlock) |
| ⭐⭐ | First 35-win streak |
| ⭐⭐⭐ | First 50-win streak |

**Gold Streak Badge** (unlocked when user first achieves 50-win streak)
| Star | Requirement |
|---|---|
| ⭐ | First 50-win streak (concurrent with Silver ⭐⭐⭐ unlock) |
| ⭐⭐ | First 75-win streak |
| ⭐⭐⭐ | First 100-win streak |

Gold ⭐⭐⭐ (100-win streak) is the highest gamified achievement in the app.

On badge unlock and star upgrade: full-screen celebration animation. Sound effect (user can mute). Share button (Post-MVP — share badge card to social media).

### 2.3 Consistency Badge (Post-MVP Phase 1)

**Requirement:** Maintain risk per trade below 2% of Practice Equity for 50 consecutive trades.

Rationale: Rewards disciplined position sizing, not just directional accuracy. A user can have a great win rate with reckless lot sizes and still be unprepared for live trading. This badge is visible on the leaderboard and signals a different kind of competence.

| Star | Requirement |
|---|---|
| ⭐ | 50 consecutive trades under 2% risk |
| ⭐⭐ | 150 consecutive trades under 2% risk |
| ⭐⭐⭐ | 300 consecutive trades under 2% risk |

### 2.4 Badge Display Rules

- **Leaderboard:** Shows highest streak badge (with current star count) + learning badge. Space-constrained. Two badges maximum.
- **Profile:** Full badge case. All earned badges displayed in grid. Locked badges shown as greyed-out silhouettes with unlock condition tooltip.
- **Session screen:** No badges displayed during active trading. Distraction risk.
- **Post-trade screen:** Badge unlock celebration shown if a badge is earned as a result of that trade.

---

## 3. Streak Mechanics — Detailed Rules

### 3.1 What Counts as a Streak Trade
Only trades where the user committed to a direction (Buy or Sell) and received a definitive outcome (TP hit or SL hit) count toward streak.

- Neutral outcomes: do NOT break streak, do NOT advance streak
- Correct No-Trade: does NOT advance streak, does NOT break streak
- Incorrect No-Trade: does NOT break streak (no-trade is never punished)

### 3.2 Cross-Session Streaks
Win streaks persist across sessions. If a user ends Session 12 with a 9-win streak and opens Session 13, their streak begins at 9 going into the first decision point.

### 3.3 Streak Display
- Current streak counter displayed on session screen (subtle, bottom corner — not the focus)
- Streak milestone pop-up when crossing tier boundary (entering 5, 10, 20, 30+ territory)
- Streak loss: brief notification only. No dramatic animation. No rubbing it in.

### 3.4 Streak Cooldown Mode (Stage 4 Only — see LEARNING_THEORY.md)
Users in Stage 4 (Sessions 301–500) on a streak of 15+ wins will, 1 in every 5 sessions, receive a "Hard Mode" session with ambiguous setups. This session is unlabelled as Hard Mode until after completion. Prevents streak-chasing overconfidence. Win/loss outcomes and points apply normally.

---

## 4. Competitions (Post-MVP Phase 2)

**Do not build until legal review is complete. See REGULATORY_NOTES.md.**

Design intent (for architecture planning only):

- Time-limited competitions: weekly and monthly cadence
- Separate leaderboard for each competition. Main leaderboard unaffected.
- Competition ranking: composite score (points earned during window + win rate during window). Not raw points — prevents volume gaming.
- Entry: automatic for all users. No entry fee.
- Prizes: cash (pending legal) or in-app premium features (safe fallback)
- Geographic tiers: country, regional, global (within each competition)
- Badge: Competition Winner badge. Separate from streak/learning badges.

---

## 5. Economy Health Checks

The following conditions indicate the economy needs rebalancing. Monitor post-launch:

| Signal | Threshold | Action |
|---|---|---|
| Median user points growing faster than win rate | Points growing 2× faster than win rate suggests easy grind | Review streak multiplier tiers |
| Leaderboard dominated by session-volume users | Top 10 all have 500+ sessions, sub-55% win rates | Introduce Quality Score weighting |
| Floor hit rate above 30% of active users | Economy too punishing or win rate too low | Review dataset difficulty curation |
| No Trade usage below 10% of decision points | Users not engaging with the mechanic | Review UI prominence of No Trade option |
| Practice Equity margin call rate above 40% | Risk mechanics feedback not landing | Review post-trade equity card design |
