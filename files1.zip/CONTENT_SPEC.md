# CONTENT_SPEC.md — TradeWise Content Specification

**Version:** 0.1  
**Owner:** Masood  
**Critical dependency:** This document must be validated by a trader who actively trades these setups before dataset curation begins.

---

## Purpose

This document defines:
1. The 5 core confluence setups the app teaches
2. How each setup is presented across the 4 learning stages
3. What constitutes a "trap" (no-trade) setup
4. The dataset curation requirements for the MVP chart replay pool
5. The coaching card content structure

Without this document, the dataset curators (or the person tagging decision points) have no rules to work from. This is the content rulebook.

---

## 1. The 5 Core Confluence Setups

A confluence is defined as the combination of two or more independent signals that agree on direction. No single signal alone is sufficient. The app teaches five foundational confluences that are:

- Observable on a 5-minute chart with 15-minute and 1-hour context
- Applicable to EURUSD (MVP) and extensible to other instruments
- Teachable progressively (not all introduced at Stage 1)

---

### Setup 1: Key Level + Candlestick Confirmation
**Introduced:** Stage 1 (Sessions 1–50)  
**Difficulty:** Foundation

**Components:**
- Component A: Price at a identified key level (support or resistance). The level must be clearly formed — at least 2 prior touches on the same level, visible on the 5-minute chart.
- Component B: A reversal candlestick pattern at that level (bullish engulfing, bearish engulfing, pin bar, hammer, shooting star). Pattern must close at or within 10 pips of the key level.

**Valid confluence (BUY):** Price touches identified support level + bullish engulfing or pin bar closes at that level.  
**Valid confluence (SELL):** Price touches identified resistance level + bearish engulfing or shooting star closes at that level.

**Trap version (No Trade):** Price approaches a key level but the confirming candle is ambiguous (e.g. a doji or a candle with near-equal bodies in both directions). No clean signal. Correct answer: No Trade.

**Stage 1 presentation:**
- Key level marked with a horizontal line on the chart before the decision point
- Candlestick pattern named in the post-trade coaching card

**Stage 2+ presentation:**
- No pre-marked level. User must identify it using the horizontal line tool during the pause.

---

### Setup 2: Trend Continuation + Fibonacci Retracement
**Introduced:** Stage 2 (Sessions 51–150)  
**Difficulty:** Intermediate

**Components:**
- Component A: Clear trend on the 1-hour timeframe (series of higher highs + higher lows for uptrend; lower highs + lower lows for downtrend). Minimum 3 swing points visible.
- Component B: Price retraces to the 50% or 61.8% Fibonacci level of the most recent impulse move on the 5-minute chart.
- Component C (optional, strengthens confluence): A candlestick confirmation at the Fib level (same patterns as Setup 1)

**Valid confluence (BUY):** 1H uptrend + price pulls back to 50%/61.8% Fib of last up-impulse + bullish candlestick at Fib level.  
**Valid confluence (SELL):** 1H downtrend + price retraces to 50%/61.8% Fib of last down-impulse + bearish candlestick at Fib level.

**Trap version:** Price retraces to Fib level but 1H trend is ambiguous (ranging, not trending). Taking a trade here is fighting the lack of structure. Correct answer: No Trade.

**Stage 2 presentation:**
- 1H chart available via timeframe toggle. User must switch to verify trend.
- Fibonacci tool available in charting tools panel.

---

### Setup 3: Market Structure Break + Retest
**Introduced:** Stage 2 (Sessions 100–150)  
**Difficulty:** Intermediate

**Components:**
- Component A: A clear break of a prior swing high (BUY setup) or swing low (SELL setup) on the 5-minute chart. Break defined as a candle closing beyond the prior swing point by at least 10 pips.
- Component B: Price returns to retest the broken level (now acting as new support/resistance).
- Component C: A candlestick confirmation at the retest level.

**Valid confluence (BUY):** Prior resistance broken → price retests that level from above → bullish candle confirms support.  
**Valid confluence (SELL):** Prior support broken → price retests that level from below → bearish candle confirms resistance.

**Trap version:** Price breaks a level but returns aggressively through it before retest (false break / liquidity sweep). The "retest" is actually a continuation of the break. No Trade is correct.

**Note for dataset curators:** The trigger_candle_index should be placed at the retest confirmation candle, not at the break candle. The break itself should be visible in the chart history that plays before the pause.

---

### Setup 4: Multi-Timeframe Confluence (Session + Structure)
**Introduced:** Stage 3 (Sessions 151–300)  
**Difficulty:** Advanced

**Components:**
- Component A: A key level on the 1-hour chart (must be visible when user switches to 1H via toggle)
- Component B: A market structure shift on the 5-minute chart at that 1H level (a break of a lower-timeframe swing, indicating short-term momentum aligning with the 1H level)
- Component C: A candlestick confirmation on the 5-minute chart

**Valid confluence (BUY):** 1H key support level + 5M structure shift to the upside + 5M bullish candle.  
**Valid confluence (SELL):** 1H key resistance level + 5M structure shift to the downside + 5M bearish candle.

**Trap version:** The 1H level is present but the 5M structure has not shifted — price is still making lower highs against the 1H support. Buying into a level with no 5M momentum confirmation. Correct answer: No Trade.

**This is the most complex setup in MVP.** It requires the user to actively use the timeframe toggle and synthesise information across two timeframes. Only introduced at Stage 3.

---

### Setup 5: Compression Breakout
**Introduced:** Stage 3 (Sessions 200–300)  
**Difficulty:** Advanced

**Components:**
- Component A: Price is in compression — a narrowing range (lower highs and higher lows converging) visible over at least 10 candles on the 5-minute chart.
- Component B: A breakout candle — a candle that closes outside the compression range with a body at least 1.5× the average candle body size of the compression period.
- Component C: The breakout direction must be aligned with the 15-minute trend direction.

**Valid confluence (BUY):** Compression identified + bullish breakout candle closes above compression range + 15M trend is up (or ranging — compression breakout in direction of most recent 15M momentum).  
**Valid confluence (SELL):** Compression + bearish breakout candle + 15M confirms or is neutral.

**Trap version:** A breakout candle appears but closes back inside the compression range on the same 5-minute candle (a wick breakout, not a body close). Or breakout direction directly opposes a strong 15M or 1H trend. Correct answer: No Trade.

---

## 2. The Trap Setup Library

Trap setups (where No Trade is the correct answer) must constitute the following proportion of decision points per stage:

| Stage | Trap % of decision points |
|---|---|
| 1 | 10% (1 in 10) — build awareness, not pressure |
| 2 | 25% (1 in 4) — user should start recognising bad setups |
| 3 | 35% (1 in 3) — no-trade discipline actively trained |
| 4 | 40% — approaching real market noise levels |

**Trap types to include:**

| Trap Name | Description |
|---|---|
| Ambiguous candle | A doji or inside bar at a key level. No clear directional signal. |
| False break | Price breaks a level but the candle closes back through it. |
| Counter-trend entry | Valid-looking setup but against a strong higher timeframe trend. |
| No structure | Price in open space between levels. No identifiable setup. |
| Early entry | The setup is forming but not yet confirmed (pattern incomplete). |
| News trap | (Stage 3+) A sharp directional move with no structure basis — simulating news-driven volatility that has no tradeable confluence. |

---

## 3. Market Condition Dataset Requirements

The dataset pool must include all four market conditions. Approximate distribution for MVP dataset pool:

| Condition | % of total datasets | Notes |
|---|---|---|
| Trending (up or down) | 40% | Split roughly equally between up and down |
| Ranging | 30% | Clear support/resistance boundaries |
| Compression | 20% | Includes compression breakout setups |
| High Volatility | 10% | Stage 3+ only. Sharp moves, traps, news-simulation |

---

## 4. Dataset Curation Requirements

Each dataset must be tagged before it can be used in the app.

**Dataset-level tags (in `datasets` table):**
- instrument, timeframe, market_condition, stage_min, stage_max, is_trap_session

**Decision-point-level tags (in `decision_points` table):**
Every decision point in a dataset must have:
- `trigger_candle_index` — the candle where the chart pauses
- `correct_direction` — buy, sell, or no_trade
- `is_trap_setup` — boolean
- `setup_type` — one of the 5 setup names above (or 'trap_[type]' for traps)
- `setup_components` — JSON array of the component names that form the confluence
- `outcome_candle_index` — where outcome resolves (TP/SL hit)
- All SL/TP preset values in pips (tight, moderate, wide)
- `max_favourable_pips` — for Professional tier bonus
- `coaching_text_win` and `coaching_text_loss` — Stage 1 coaching card text

**Minimum dataset pool for MVP launch:**
- 20 datasets minimum
- At least 4 in each market condition
- At least 2 Stage 1-only (clean, unambiguous, no traps)
- At least 3 trap-heavy sessions (is_trap_session = true)
- At least 60 total unique decision points across the pool

---

## 5. Coaching Card Content

Coaching cards are shown after each trade in Stage 1, and after losses only in Stage 2+.

**Win coaching card format (Stage 1):**
> "Nice trade. This was a [Setup Name] setup. [Component A] was at [description]. [Component B] confirmed the direction. In a live account, your next step after a win like this is to review whether your SL placement gave the trade enough room."

**Loss coaching card format (Stage 1):**
> "This was still a [Setup Name] setup — the direction was [correct/incorrect]. The trade moved against you because [brief reason — e.g. 'a stronger resistance level above limited the move']. Review the 1H chart to see if there was a higher-timeframe reason to be cautious here."

**No-Trade correct (any stage):**
> "Good read. This was a [Trap Type] setup — [brief explanation of why no trade was the right call]. Avoiding bad setups is as valuable as taking good ones."

**No-Trade incorrect — valid setup was skipped (any stage):**
> "This was a valid [Setup Name] confluence. No points lost — sitting out of a good trade is always safe. Review the setup components to see what to look for next time."

All coaching card text must be written before dataset launch. A spreadsheet template is provided in the curation workflow (see ROADMAP.md — Phase 0 tasks).

---

## 6. Learning Module Content Outline

### Section 1: What Is a Financial Market
- What markets exist (Forex, Metals, Crypto, Stocks — brief)
- Who trades them and why
- What moves price (supply and demand, simplified)
- Quiz: 3 questions on basic market concepts

### Section 2: Reading a Candlestick Chart
- What a candlestick represents (OHLC)
- Timeframes explained (1M, 5M, 15M, 1H, 4H, D1)
- How to read a chart left to right
- Quiz: 3 questions on candlestick reading

### Section 3: Market Structure
- Trend (higher highs/higher lows, lower highs/lower lows)
- Range (equal highs/lows)
- Key levels (support, resistance)
- Quiz: 3 questions on structure identification

### Section 4: What Is a Confluence
- Definition: two or more signals agreeing on direction
- Introduction to all 5 setups (overview only — depth comes through practice)
- Why one signal is not enough
- Quiz: 3 questions on confluence concept

### Section 5: Risk Management
- What is a Stop Loss and why it is not optional
- What is a Take Profit
- Lot size explained (what 0.01 lots means in practice)
- Pip value calculation (worked example on EURUSD)
- Risk per trade % (definition of 1% risk rule)
- Worked example: "You have $10,000. 1% risk = $100. If SL is 50 pips, your max lot size is..."
- Quiz: 3 questions including a calculation question

### Section 6: Margin and Leverage
- What leverage means (amplification — both ways)
- What margin is (collateral, not a fee)
- What a margin call is
- Why high leverage is dangerous for new traders
- Quiz: 3 questions

### Section 7: What Is a Trading Plan
- Why a plan matters (removes emotion from decisions)
- The three questions of a trading plan: What do I trade? When do I trade? How much do I risk?
- TradeWise as a practice environment for developing your answers
- Quiz: 3 questions

**Total estimated reading time per section:** 4–7 minutes.  
**Total estimated module completion time:** 35–50 minutes.
