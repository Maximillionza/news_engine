# LEARNING_THEORY.md — TradeWise Pedagogical Framework

**Version:** 0.1  
**Owner:** Masood  
**Critical dependency:** Every feature in the trading loop must be validated against this document before build.

---

## Why This Document Exists

Every advisor in the initial council review identified the same gap: the feature list exists, but the learning theory underneath it does not. This document defines what "trained" means at each stage, what cognitive skills the app is actually developing, and how the session architecture must evolve across 500 sessions. Without this, the app is a scoring game, not a training tool.

---

## 1. The Four Competency Pillars

A trader who is genuinely prepared to trade live demonstrates competence across four pillars. TradeWise must develop all four. The table below maps each pillar to how the app addresses it.

| Pillar | What It Means | How TradeWise Addresses It | Risk if Skipped |
|---|---|---|---|
| **1. Market Structure Literacy** | Can identify trend, range, compression, and key price levels across timeframes | Chart replay datasets curated to show all conditions. Learning module section 3. Timeframe toggle during decision point. | User only recognises clean trending setups. Fails in ranging markets. |
| **2. Pre-Hoc Conviction** | Can identify a valid confluence and commit to a directional bias BEFORE price moves | The core mechanic: chart pauses before the move. User must commit all inputs before chart plays. | Without this pillar, user learns post-hoc labelling, not real trading decisions. This is the most common failure of replay tools. |
| **3. Risk Mechanics** | Understands and correctly applies lot sizing, SL placement, risk-per-trade %, and margin | Practice Equity tracker. Lot size input. SL/TP input. Post-trade equity impact display. Risk management module. | User develops directional skill with no position sizing discipline. Will blow live account through overleveraging, even with correct direction calls. |
| **4. Psychological Discipline** | Knows when NOT to trade. Tolerates uncertainty. Maintains consistent process under a losing streak. | "No Trade" option at every decision point. Points floor (no game-over). Coaching messages on losing streaks. No streak-loss penalty (removes panic). | User trained to always take a position. Overtrading is the single most cited reason new traders lose money. |

---

## 2. The Pre-Hoc vs Post-Hoc Distinction (Critical)

This is the single most important pedagogical principle in the app. Developers and designers must understand it.

**Post-hoc pattern matching** (what most replay tools teach):
> Chart is playing. User watches price move. User is asked "was that a buy or sell?" User labels what already happened.

This trains recognition of completed patterns. It does not train the ability to act before the move. It produces users who can analyse charts in hindsight but freeze or guess in real-time.

**Pre-hoc conviction** (what TradeWise trains):
> Chart pauses. User sees only the setup forming. User must commit to direction, size, SL, and TP before seeing the outcome. Chart then plays.

This trains the actual cognitive process of trading: identifying a setup, building a thesis, sizing appropriately, and committing — all under uncertainty.

**Rule for all developers:** Any feature that allows the user to see price movement before committing to a trade decision breaks this mechanic. Flag it and escalate to Masood before building.

---

## 3. Session Progression Architecture

The learning experience must change as the user develops. Session 1 and Session 499 must feel fundamentally different. Below is the progression arc.

### Stage 1: Foundation (Sessions 1–50)
**User state:** Overwhelmed. Doesn't know what to look for. High dropout risk.

**Design principles:**
- Clean, unambiguous setups only. No traps, no marginal confluences.
- Explicit setup labelling AFTER the trade. ("This was a [Support Level + Bullish Engulfing] confluence.")
- Lot size options: simple (0.01, 0.05, 0.10 lots only)
- SL/TP: preset only. No user-defined.
- "No Trade" available but not punished if missed (user is still learning what a valid setup looks like)
- Post-trade coaching card shown after every trade — win or lose
- 3 trade opportunities per session maximum

**Success metric for this stage:** User can correctly identify setup type after seeing outcome. Win rate above 50%.

---

### Stage 2: Pattern Recognition (Sessions 51–150)
**User state:** Recognises individual signals. Struggles to combine them into confluences.

**Design principles:**
- Introduce multi-signal confluences (2-component setups)
- Begin introducing marginal setups where No Trade is the correct answer (25% of decision points)
- Lot size options expanded (0.01–0.50 lots)
- SL/TP: preset but with 3 options to choose from (tight, moderate, wide). User must choose.
- Post-trade card now shows: "Your SL was [X pips]. At 0.10 lots, that risked $[Y] on a $10,000 account = [Z]% risk."
- 4–5 trade opportunities per session

**Success metric for this stage:** Win rate sustained above 50% with multi-signal confluences. No Trade correctly selected >40% of the time when a trap is presented.

---

### Stage 3: Confluence Mastery (Sessions 151–300)
**User state:** Can identify setups. Inconsistent on risk management. May overtrade.

**Design principles:**
- Full 5-setup curriculum active (see CONTENT_SPEC.md)
- All market conditions: trending, ranging, compression, high-volatility
- No Trade correct answer for 35% of decision points
- Lot size: full range available. Practice Equity impact shown before confirmation (not after)
- SL/TP: 5 preset options OR user-defined (user chooses mode once per session)
- Introduce "risk budget" concept: each session user has a maximum risk budget (2% of Practice Equity). Selecting a lot size that exceeds budget triggers warning, not block.
- Sessions extended: 5–7 opportunities
- Coaching cards reduced frequency (now only on loss, not every trade)

**Success metric for this stage:** User maintains consistent risk per trade. Win rate 55%+. No Trade correctly selected >60% when trap presented.

---

### Stage 4: Independence (Sessions 301–500)
**User state:** Has internalised core setups. Ready to develop personal edge.

**Design principles:**
- Mixed difficulty — easy through hard setups, unlabelled
- No Trade correct for 40% of decision points
- No post-trade labels. Only result and equity impact.
- User-defined SL/TP default
- Full risk mechanics active including margin call simulation
- Practice Readiness Score visible and updated after each session
- Introduce session review: at end of session, user sees all 5–7 decision points with their choices vs optimal choices. No score impact. Pure learning.
- "Streak cooldown" mode: if user is on a 15+ win streak, 1 in 5 sessions presents deliberately ambiguous setups. Prevents overconfidence in hot streak.

**Success metric for this stage:** Practice Readiness Score 61+. Consistent risk management. Win rate meaningful vs random (above 55% sustained over 100 trades).

---

## 4. What "500 Sessions" Means

The 500-session target is not a graduation guarantee. It is a threshold at which a user who has engaged seriously with the progression architecture will have:

- Seen and acted on approximately 2,000–3,000 individual trade decision points
- Practised all 5 core confluence setups across all 4 market conditions
- Made hundreds of position sizing decisions with real equity consequence (simulated)
- Experienced at least one Practice Equity drawdown severe enough to trigger the margin warning
- Developed a personal preference pattern (which setups they perform best on)

The Practice Readiness Score aggregates this. A user with 500 sessions and a score of 35 is not ready. A user with 300 sessions and a score of 78 may be more prepared than most.

**The app never tells a user they are ready to trade live. It reflects their practice quality. The user decides when to cross that line.**

---

## 5. The "No Trade" Mechanic — Rationale

Overtrading is cited by independent analysis of retail trading accounts as a primary contributor to losses. New traders take positions on every bar because:
- They believe they need to be "in the market" to make money
- They feel inaction is wasted time
- They have not internalised that avoiding bad trades is as valuable as taking good ones

The No Trade option addresses this directly. At every decision point, the correct answer may be to not trade. The app must reward this selection when correct and not punish it when incorrect (user thought there was no setup but there was one — this is a learning moment, not a failure).

This is the feature most likely to be removed in a design review because it "reduces engagement." It must not be removed. It is pedagogically central.

---

## 6. Risk Management as a Live Mechanic, Not a Quiz

The council review was clear on this: risk management cannot be taught through a learning card or a quiz. It must be experienced as a consequence.

TradeWise implements this through the Practice Equity system:

- Every lot size decision has a real pip-value consequence on a $10,000 simulated account
- A 50-pip SL on 1.0 lot costs $500 in Practice Equity if hit — 5% of account in one trade
- The user sees this before locking in, sees the outcome after, and accumulates a track record
- The margin call simulation at $500 Practice Equity creates the visceral experience of overleveraging — safely

The post-trade card must always show:
1. Direction: correct or incorrect
2. Risk taken: [lot size] × [SL pips] = $[amount] = [%] of Practice Equity
3. Outcome: +$[amount] or −$[amount] to Practice Equity
4. Optimal risk: what a 1% risk per trade would have been on this setup

Over hundreds of trades, this builds an internalized sense of position sizing. No quiz achieves this.

---

## 7. Emotional Discipline — What the App Can and Cannot Do

The app can:
- Create the pattern of deciding before knowing
- Simulate financial consequence without real loss
- Reward consistency over hot streaks
- Introduce ambiguous setups to prevent overconfidence
- Show streak data to help users see their own emotional patterns

The app cannot:
- Replicate the adrenaline of real money at risk
- Prevent a user from applying zero discipline to their live account
- Train the full emotional experience of a 10-trade losing streak with real money

This gap must be acknowledged in the disclaimer architecture (see FR-015 in PRD.md). The app is not claiming to fully prepare users for live trading psychology. It is building the cognitive foundation. The emotional layer must be developed carefully in live trading with strict risk limits.

---

## 8. Curriculum Completion vs Skill Acquisition

The learning module completion (badge award) is a curriculum milestone, not a competence certification. A user who completes the learning module has been exposed to the concepts. A user with 300 quality sessions has begun to internalise them.

The badge and the Practice Readiness Score measure different things and must never be conflated in the UI:

| Metric | What It Measures |
|---|---|
| Learning Badge (Bronze/Silver/Gold) | Curriculum completion |
| Win Streak Badge | Consecutive correct directional calls |
| Practice Readiness Score | Composite practice quality across all four pillars |

No single metric tells the full story. The profile screen must display all three clearly and distinctly.
